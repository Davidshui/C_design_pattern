// led.h
#ifndef LED_H
#define LED_H

#include <stdint.h>

typedef struct led led_t;

struct led {
    void (*init)(led_t *led);
    void (*on)(led_t *led);
    void (*off)(led_t *led);
    void (*toggle)(led_t *led);
    void (*set_brightness)(led_t *led, uint8_t brightness);  // 0~100
};

#endif