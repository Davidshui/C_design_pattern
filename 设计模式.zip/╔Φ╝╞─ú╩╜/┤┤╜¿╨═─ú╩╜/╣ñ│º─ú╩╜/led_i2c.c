// led_i2c.c
#include "led.h"
// 假设已有I2C底层驱动
extern void i2c_write_register(uint8_t dev_addr, uint8_t reg, uint8_t data);

typedef struct {
    led_t base;
    uint8_t i2c_addr;
    uint8_t pin_mask;
    uint8_t current_state;
} led_i2c_t;

static void i2c_init(led_t *led)
{
    led_i2c_t *self = (led_i2c_t *)led;
    self->current_state = 0;
}

static void i2c_on(led_t *led)
{
    led_i2c_t *self = (led_i2c_t *)led;
    self->current_state |= self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);
}

static void i2c_off(led_t *led)
{
    led_i2c_t *self = (led_i2c_t *)led;
    self->current_state &= ~self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);
}

static void i2c_toggle(led_t *led)
{
    led_i2c_t *self = (led_i2c_t *)led;
    self->current_state ^= self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);
}

static void i2c_set_brightness(led_t *led, uint8_t brightness)
{
    (void)brightness;
}

void led_i2c_init(led_t *led, uint8_t dev_addr, uint8_t pin_mask)
{
    led_i2c_t *self = (led_i2c_t *)led;
    self->base.init            = i2c_init;
    self->base.on              = i2c_on;
    self->base.off             = i2c_off;
    self->base.toggle          = i2c_toggle;
    self->base.set_brightness  = i2c_set_brightness;
    self->i2c_addr     = dev_addr;
    self->pin_mask     = pin_mask;
    self->current_state = 0;
}