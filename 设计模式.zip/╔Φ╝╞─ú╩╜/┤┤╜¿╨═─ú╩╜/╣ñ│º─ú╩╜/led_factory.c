// led_factory.c
#include "led_factory.h"
#include "led_stm32_gpio.h"
#include "led_i2c.h"

// 工厂内部使用的静态内存池（每个类型一个实例）
static led_stm32_gpio_t  gpio_instance;
static led_i2c_t         i2c_instance;
// static led_pwm_t      pwm_instance;   // 可继续扩展

led_t *led_factory_create(const led_config_t *config)
{
    if (config == NULL) {
        return NULL;
    }

    led_t *led = NULL;

    switch (config->type) {
        case LED_TYPE_STM32_GPIO:
            if (config->gpio.port != NULL) {
                led_gpio_init(&gpio_instance.base, config->gpio.port, config->gpio.pin);
                led = &gpio_instance.base;
            }
            break;

        case LED_TYPE_I2C_PCA9557:
            led_i2c_init(&i2c_instance.base, config->i2c.dev_addr, config->i2c.pin_mask);
            led = &i2c_instance.base;
            break;

        case LED_TYPE_PWM_TIMER:
            // 留空或实现PWM版本
            // led = pwm_create(...);
            break;

        default:
            // 不支持的类型
            break;
    }

    return led;
}