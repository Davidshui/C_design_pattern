// led_stm32_gpio.c
#include "led.h"
#include "stm32f4xx_hal.h"

typedef struct {
    led_t base;
    GPIO_TypeDef *port;
    uint16_t      pin;
} led_stm32_gpio_t;

static void gpio_init(led_t *led)
{
    // GPIO已在CubeMX或上层初始化
}

static void gpio_on(led_t *led)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)led;
    HAL_GPIO_WritePin(self->port, self->pin, GPIO_PIN_SET);
}

static void gpio_off(led_t *led)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)led;
    HAL_GPIO_WritePin(self->port, self->pin, GPIO_PIN_RESET);
}

static void gpio_toggle(led_t *led)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)led;
    HAL_GPIO_TogglePin(self->port, self->pin);
}

static void gpio_set_brightness(led_t *led, uint8_t brightness)
{
    (void)brightness;   // GPIO不支持PWM
}

void led_gpio_init(led_t *led, GPIO_TypeDef *port, uint16_t pin)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)led;
    self->base.init            = gpio_init;
    self->base.on              = gpio_on;
    self->base.off             = gpio_off;
    self->base.toggle          = gpio_toggle;
    self->base.set_brightness  = gpio_set_brightness;
    self->port = port;
    self->pin  = pin;
}