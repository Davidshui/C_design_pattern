// led_factory.h
#ifndef LED_FACTORY_H
#define LED_FACTORY_H

#include "led.h"
#include <stdint.h>

// LED支持的类型
typedef enum {
    LED_TYPE_STM32_GPIO = 0,
    LED_TYPE_I2C_PCA9557,
    LED_TYPE_PWM_TIMER,
    LED_TYPE_MAX
} led_type_t;

// 配置结构体（参数化配置，调用者填充）
typedef struct {
    led_type_t type;                // 必须指定类型

    // GPIO 配置
    struct {
        GPIO_TypeDef *port;
        uint16_t      pin;
    } gpio;

    // I2C 配置
    struct {
        uint8_t  dev_addr;          // I2C设备地址
        uint8_t  pin_mask;          // 对应芯片的引脚位掩码
    } i2c;

    // PWM 配置
    struct {
        TIM_HandleTypeDef *htim;    // 定时器句柄
        uint32_t           channel; // PWM通道 (TIM_CHANNEL_1 等)
    } pwm;

} led_config_t;

// 工厂创建函数（推荐写法）
led_t *led_factory_create(const led_config_t *config);

#endif