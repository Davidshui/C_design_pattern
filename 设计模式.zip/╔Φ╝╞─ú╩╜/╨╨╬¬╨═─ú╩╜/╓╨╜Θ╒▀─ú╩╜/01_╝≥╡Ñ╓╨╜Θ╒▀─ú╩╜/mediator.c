/* mediator.c */
#include "mediator.h"
#include <stdio.h>

void central_mediator_init(central_mediator_t *med)
{
    med->base.send = (void(*)(mediator_t*,colleague_t*,const message_t*))central_mediator_send;
    med->base.register_colleague = (void(*)(mediator_t*,colleague_t*))central_mediator_register;
    med->count = 0;
}

void central_mediator_register(central_mediator_t *med, colleague_t *col)
{
    if (med->count >= 8) return;
    med->colleagues[med->count++] = col;
    printf("[Mediator] 已注册模块: %s\n", col->name);
}

void central_mediator_send(central_mediator_t *med, colleague_t *sender, const message_t *msg)
{
    printf("[Mediator] 转发消息: 类型=%d, 值=%u (来自 %s)\n", 
           msg->type, msg->value, sender ? sender->name : "系统");

    for (int i = 0; i < med->count; i++) {
        colleague_t *col = med->colleagues[i];
        /* 不发回给发送者 */
        if (col != sender && col->receive) {
            col->receive(col, msg);
        }
    }
}