/* mediator.h */
#ifndef EMBEDDED_MEDIATOR_H
#define EMBEDDED_MEDIATOR_H

#include <stdint.h>
#include <stdbool.h>

typedef enum {
    MSG_SENSOR_UPDATE,      // 传感器数据更新
    MSG_ACTUATOR_CMD,       // 执行器控制命令
    MSG_DISPLAY_REFRESH,    // 请求刷新显示
    MSG_BUTTON_PRESS,       // 按键事件
    MSG_COMM_SEND,          // 需要发送到云端
    MSG_ALARM_TRIGGER,      // 报警触发
    MSG_SYSTEM_STATUS       // 系统状态变化
} msg_type_t;

typedef struct {
    msg_type_t type;
    uint32_t   value;       // 温度、湿度、命令码等
    uint8_t    sensor_id;   // 传感器编号
    const char *text;       // 可选文本描述
} message_t;

/* 同事（Colleague）结构体 */
typedef struct colleague colleague_t;

typedef void (*colleague_receive_fn)(colleague_t *self, const message_t *msg);

struct colleague {
    colleague_receive_fn receive;
    const char *name;
};

/* 中介者接口 */
typedef struct mediator {
    void (*send)(struct mediator *med, colleague_t *sender, const message_t *msg);
    void (*register_colleague)(struct mediator *med, colleague_t *col);
} mediator_t;

/* 具体中介者（支持最多 8 个模块） */
typedef struct {
    mediator_t base;
    colleague_t *colleagues[8];
    int count;
} central_mediator_t;

/* 初始化 */
void central_mediator_init(central_mediator_t *med);

/* 注册模块 */
void central_mediator_register(central_mediator_t *med, colleague_t *col);

/* 发送消息 */
void central_mediator_send(central_mediator_t *med, colleague_t *sender, const message_t *msg);

#endif