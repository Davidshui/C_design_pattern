/* main.c */
#include "mediator.h"
#include <stdio.h>

extern colleague_t* get_sensor_module(void);
extern colleague_t* get_actuator_module(void);
extern colleague_t* get_display_module(void);
extern colleague_t* get_comm_module(void);

int main(void)
{
    central_mediator_t mediator;
    central_mediator_init(&mediator);

    /* 注册所有模块 */
    central_mediator_register(&mediator, get_sensor_module());
    central_mediator_register(&mediator, get_actuator_module());
    central_mediator_register(&mediator, get_display_module());
    central_mediator_register(&mediator, get_comm_module());

    printf("\n=== 嵌入式中介者模式 - 智能设备控制系统 ===\n\n");

    /* 模拟传感器采集到高温 */
    message_t msg1 = {MSG_SENSOR_UPDATE, 950, 1, NULL};
    central_mediator_send(&mediator, get_sensor_module(), &msg1);

    /* 模拟按键触发报警 */
    message_t msg2 = {MSG_ALARM_TRIGGER, 0, 0, "温度过高"};
    central_mediator_send(&mediator, get_display_module(), &msg2);

    /* 模拟控制器要求执行动作 */
    message_t msg3 = {MSG_ACTUATOR_CMD, 1000, 0, NULL};
    central_mediator_send(&mediator, get_actuator_module(), &msg3);

    return 0;
}