/* colleagues.c */
#include "mediator.h"
#include <stdio.h>

/* ====================== 传感器模块 ====================== */
static void sensor_receive(colleague_t *self, const message_t *msg)
{
    (void)self;
    if (msg->type == MSG_SENSOR_UPDATE) {
        printf("[Sensor] 收到自身数据确认: 传感器%d 值=%u\n", msg->sensor_id, msg->value);
    }
}

static colleague_t sensor_module = {
    .receive = sensor_receive,
    .name = "SensorModule"
};

/* ====================== 执行器模块 ====================== */
static void actuator_receive(colleague_t *self, const message_t *msg)
{
    (void)self;
    if (msg->type == MSG_ACTUATOR_CMD) {
        printf("[Actuator] 执行命令: 值=%u\n", msg->value);
        if (msg->value > 800) {
            printf("[Actuator] 启动风扇/报警器！\n");
        }
    }
}

static colleague_t actuator_module = {
    .receive = actuator_receive,
    .name = "ActuatorModule"
};

/* ====================== 显示模块 ====================== */
static void display_receive(colleague_t *self, const message_t *msg)
{
    (void)self;
    if (msg->type == MSG_DISPLAY_REFRESH) {
        printf("[Display] 刷新屏幕显示: %u\n", msg->value);
    } else if (msg->type == MSG_ALARM_TRIGGER) {
        printf("[Display] 显示报警界面: %s\n", msg->text ? msg->text : "ALARM!");
    }
}

static colleague_t display_module = {
    .receive = display_receive,
    .name = "DisplayModule"
};

/* ====================== 通信模块 ====================== */
static void comm_receive(colleague_t *self, const message_t *msg)
{
    (void)self;
    if (msg->type == MSG_COMM_SEND) {
        printf("[Communication] 准备上报云端: 值=%u\n", msg->value);
    }
}

static colleague_t comm_module = {
    .receive = comm_receive,
    .name = "CommModule"
};

/* 对外接口 */
colleague_t* get_sensor_module(void)    { return &sensor_module; }
colleague_t* get_actuator_module(void)  { return &actuator_module; }
colleague_t* get_display_module(void)   { return &display_module; }
colleague_t* get_comm_module(void)      { return &comm_module; }