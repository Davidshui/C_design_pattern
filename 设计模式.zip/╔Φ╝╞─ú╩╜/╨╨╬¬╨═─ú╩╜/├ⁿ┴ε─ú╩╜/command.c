/* command.c */
#include "command.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void command_execute(struct command *cmd)
{
    if (cmd && cmd->ops && cmd->ops->execute)
        cmd->ops->execute(cmd->priv);
}

void command_undo(struct command *cmd)
{
    if (cmd && cmd->ops && cmd->ops->undo)
        cmd->ops->undo(cmd->priv);
}

const char *command_get_name(struct command *cmd)
{
    if (cmd && cmd->ops && cmd->ops->get_name)
        return cmd->ops->get_name(cmd->priv);
    return "UnknownCommand";
}

/* ------------------- Invoker ------------------- */
void invoker_init(struct command_invoker *invoker, int capacity)
{
    invoker->history = calloc(capacity, sizeof(struct command *));
    invoker->history_size = 0;
    invoker->history_capacity = capacity;
}

void invoker_execute(struct command_invoker *invoker, struct command *cmd)
{
    if (!cmd) return;

    command_execute(cmd);

    /* 记录到历史（支持 Undo） */
    if (invoker->history_size < invoker->history_capacity) {
        invoker->history[invoker->history_size++] = cmd;
    } else {
        /* 简单覆盖最早的命令，实际可实现循环队列 */
        command_undo(invoker->history[0]);   /* 可选：撤销最早的 */
        memmove(invoker->history, invoker->history + 1,
                (invoker->history_capacity - 1) * sizeof(struct command *));
        invoker->history[invoker->history_capacity - 1] = cmd;
    }
}

void invoker_undo_last(struct command_invoker *invoker)
{
    if (invoker->history_size <= 0) {
        printf("[Invoker] 没有可撤销的命令\n");
        return;
    }

    struct command *last = invoker->history[--invoker->history_size];
    printf("[Invoker] 撤销命令: %s\n", command_get_name(last));
    command_undo(last);
}

void invoker_clear_history(struct command_invoker *invoker)
{
    invoker->history_size = 0;
}

void invoker_destroy(struct command_invoker *invoker)
{
    free(invoker->history);
}