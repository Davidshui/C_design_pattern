/* audio_commands.c */
#include "command.h"
#include <stdio.h>
#include <stdlib.h>

extern struct audio_player g_player;   /* 全局接收者（实际项目中建议通过 priv 传递） */

/* ====================== Play Command ====================== */
struct play_priv {
    struct audio_player *player;
};

static void play_execute(void *priv)
{
    struct play_priv *p = priv;
    p->player->is_playing = true;
    p->player->is_paused = false;
    printf("[Play] 音频开始播放\n");
}

static void play_undo(void *priv)
{
    struct play_priv *p = priv;
    p->player->is_playing = false;
    printf("[Undo Play] 音频已停止\n");
}

static const char *play_get_name(void *priv)
{
    (void)priv;
    return "PlayCommand";
}

static void play_destroy(void *priv)
{
    free(priv);
}

struct command *create_play_command(struct audio_player *player)
{
    struct command *cmd = malloc(sizeof(*cmd));
    struct play_priv *priv = malloc(sizeof(*priv));

    priv->player = player;

    static const struct command_ops ops = {
        .execute   = play_execute,
        .undo      = play_undo,
        .destroy   = play_destroy,
        .get_name  = play_get_name,
    };

    cmd->ops = &ops;
    cmd->priv = priv;
    return cmd;
}

/* ====================== VolumeUp Command ====================== */
struct volume_priv {
    struct audio_player *player;
    int delta;
    int previous_volume;   /* 用于撤销 */
};

static void volume_up_execute(void *priv)
{
    struct volume_priv *p = priv;
    p->previous_volume = p->player->volume;
    p->player->volume += p->delta;
    if (p->player->volume > 100) p->player->volume = 100;
    printf("[VolumeUp] 当前音量: %d\n", p->player->volume);
}

static void volume_up_undo(void *priv)
{
    struct volume_priv *p = priv;
    p->player->volume = p->previous_volume;
    printf("[Undo Volume] 恢复音量至: %d\n", p->player->volume);
}

static const char *volume_get_name(void *priv)
{
    (void)priv;
    return "VolumeUpCommand";
}

static void volume_destroy(void *priv)
{
    free(priv);
}

struct command *create_volume_up_command(struct audio_player *player, int delta)
{
    struct command *cmd = malloc(sizeof(*cmd));
    struct volume_priv *priv = malloc(sizeof(*priv));

    priv->player = player;
    priv->delta = delta;
    priv->previous_volume = player->volume;

    static const struct command_ops ops = {
        .execute   = volume_up_execute,
        .undo      = volume_up_undo,
        .destroy   = volume_destroy,
        .get_name  = volume_get_name,
    };

    cmd->ops = &ops;
    cmd->priv = priv;
    return cmd;
}

/* ====================== Macro Command（宏命令：夜间模式） ====================== */
struct macro_priv {
    struct command **commands;
    int count;
};

static void macro_execute(void *priv)
{
    struct macro_priv *p = priv;
    printf("[Macro] 执行夜间模式（降低音量 + 均衡器）\n");
    for (int i = 0; i < p->count; i++) {
        command_execute(p->commands[i]);
    }
}

static void macro_undo(void *priv)
{
    struct macro_priv *p = priv;
    printf("[Macro Undo] 撤销夜间模式\n");
    /* 逆序撤销 */
    for (int i = p->count - 1; i >= 0; i--) {
        command_undo(p->commands[i]);
    }
}

static const char *macro_get_name(void *priv)
{
    (void)priv;
    return "NightModeMacroCommand";
}

static void macro_destroy(void *priv)
{
    struct macro_priv *p = priv;
    free(p->commands);
    free(p);
}

struct command *create_night_mode_macro(struct audio_player *player)
{
    struct command *cmd = malloc(sizeof(*cmd));
    struct macro_priv *priv = malloc(sizeof(*priv));

    priv->count = 2;
    priv->commands = malloc(priv->count * sizeof(struct command *));

    /* 夜间模式 = 音量降低20 + 暂停 */
    priv->commands[0] = create_volume_up_command(player, -20);
    priv->commands[1] = create_play_command(player);   /* 这里可换成 Pause */

    static const struct command_ops ops = {
        .execute   = macro_execute,
        .undo      = macro_undo,
        .destroy   = macro_destroy,
        .get_name  = macro_get_name,
    };

    cmd->ops = &ops;
    cmd->priv = priv;
    return cmd;
}