/* main.c */
/**
命令模式在该示例中的体现:

解耦：      main（客户端）不直接调用音频播放器的方法，而是通过命令对象。
可扩展：    新增命令只需实现 struct command_ops 即可。
撤销支持：  每个命令都实现了 undo。
宏命令：    支持多个命令组合执行。
历史记录：  Invoker 可以记录命令序列，实现重做（Redo）也很容易扩展。
*/
#include "command.h"
#include <stdio.h>
#include <stdlib.h>

struct audio_player g_player = { .volume = 50, .is_playing = false, .is_paused = false };

int main(void)
{
    struct command_invoker invoker;
    invoker_init(&invoker, 10);

    printf("=== 音频播放器命令模式演示 ===\n\n");

    /* 创建并执行命令 */
    struct command *play_cmd = create_play_command(&g_player);
    struct command *vol_up = create_volume_up_command(&g_player, 10);
    struct command *night_mode = create_night_mode_macro(&g_player);

    invoker_execute(&invoker, play_cmd);
    invoker_execute(&invoker, vol_up);
    invoker_execute(&invoker, night_mode);

    printf("\n当前状态 - 音量: %d, 正在播放: %s\n", 
           g_player.volume, g_player.is_playing ? "是" : "否");

    /* 撤销最后一条命令 */
    printf("\n=== 执行撤销 ===\n");
    invoker_undo_last(&invoker);

    printf("撤销后状态 - 音量: %d\n", g_player.volume);

    /* 清理 */
    invoker_destroy(&invoker);
    /* 注意：具体命令的 destroy 已在 invoker 中或手动调用，这里简化未完全释放 */

    return 0;
}
