/* command.h */
#ifndef COMMAND_H
#define COMMAND_H

#include <stdbool.h>

/* 命令操作函数表 */
struct command_ops {
    void (*execute)(void *priv);
    void (*undo)(void *priv);        /* 支持撤销 */
    void (*destroy)(void *priv);
    const char *(*get_name)(void *priv);
};

/* 命令结构体（Command 对象） */
struct command {
    const struct command_ops *ops;
    void *priv;
};

/* 接收者（Receiver）：真正的执行者 - 音频播放器 */
struct audio_player {
    int volume;           /* 当前音量 0~100 */
    bool is_playing;
    bool is_paused;
    /* 可扩展更多状态 */
};

/* 调用者（Invoker）：命令队列 / 遥控器 */
struct command_invoker {
    struct command **history;   /* 已执行命令历史，用于 Undo */
    int history_size;
    int history_capacity;
};

void command_execute(struct command *cmd);
void command_undo(struct command *cmd);
const char *command_get_name(struct command *cmd);

/* Invoker 接口 */
void invoker_init(struct command_invoker *invoker, int capacity);
void invoker_execute(struct command_invoker *invoker, struct command *cmd);
void invoker_undo_last(struct command_invoker *invoker);
void invoker_clear_history(struct command_invoker *invoker);
void invoker_destroy(struct command_invoker *invoker);

#endif