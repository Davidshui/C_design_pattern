#include "observer.h"
#include <stdio.h>

/* ------------------- 显示模块观察者 ------------------- */
static void display_notify(void *priv, const sensor_data_t *data)
{
    (void)priv;
    printf("[Display] 更新屏幕 → 温度 %d.%d°C\n", 
           data->temperature/10, data->temperature%10);
    /* 实际可调用 OLED 显示函数 */
}

/* ------------------- 日志模块观察者 ------------------- */
static void log_notify(void *priv, const sensor_data_t *data)
{
    (void)priv;
    printf("[Logger] 记录数据 → Temp=%d.%d, Hum=%d.%d\n",
           data->temperature/10, data->temperature%10,
           data->humidity/10, data->humidity%10);
    /* 实际可写入 Flash 或环形缓冲 */
}

/* ------------------- 控制模块观察者（阈值控制） ------------------- */
typedef struct {
    int16_t temp_high_threshold;   // 单位 0.1°C
} control_priv_t;

static void control_notify(void *priv, const sensor_data_t *data)
{
    control_priv_t *p = (control_priv_t *)priv;
    if (data->temperature > p->temp_high_threshold) {
        printf("[Control] 温度过高！启动风扇/报警\n");
        /* 实际可操作 GPIO 或继电器 */
    }
}

/* ------------------- 云上传观察者 ------------------- */
static void cloud_notify(void *priv, const sensor_data_t *data)
{
    (void)priv;
    printf("[Cloud] 准备上传数据到服务器 → Temp=%d.%d\n",
           data->temperature/10, data->temperature%10);
    /* 实际可放入 MQTT 发送队列 */
}