/* main.c */
#include "observer.h"
#include <stdio.h>

static control_priv_t control_data = { .temp_high_threshold = 350 }; // 35.0°C

int main(void)
{
    sensor_subject_t sensor;
    sensor_subject_init(&sensor);

    /* 注册观察者（各模块独立注册） */
    sensor_subject_attach(&sensor, display_notify, NULL);
    sensor_subject_attach(&sensor, log_notify,     NULL);
    sensor_subject_attach(&sensor, control_notify, &control_data);
    sensor_subject_attach(&sensor, cloud_notify,   NULL);

    printf("=== 嵌入式观察者模式 - 传感器数据发布演示 ===\n\n");

    /* 模拟传感器多次采集数据 */
    sensor_data_t readings[3] = {
        {256, 450, 1000},   // 25.6°C, 45.0%RH
        {378, 620, 1001},   // 37.8°C, 62.0%RH → 触发控制
        {182, 380, 1002}    // 18.2°C, 38.0%RH
    };

    for (int i = 0; i < 3; i++) {
        printf("--- 第 %d 次数据更新 ---\n", i+1);
        sensor_subject_notify(&sensor, &readings[i]);
        printf("\n");
    }

    return 0;
}