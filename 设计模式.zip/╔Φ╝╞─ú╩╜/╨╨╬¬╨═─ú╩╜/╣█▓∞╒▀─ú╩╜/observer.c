/* observer.c */
#include "observer.h"
#include <stdio.h>
#include <string.h>

void sensor_subject_init(sensor_subject_t *subject)
{
    subject->count = 0;
    memset(subject->observers, 0, sizeof(subject->observers));
}

bool sensor_subject_attach(sensor_subject_t *subject,
                           observer_notify_fn notify,
                           void *priv)
{
    if (subject->count >= MAX_OBSERVERS || notify == NULL)
        return false;

    /* 防止重复注册 */
    for (int i = 0; i < subject->count; i++) {
        if (subject->observers[i].notify == notify)
            return true;
    }

    subject->observers[subject->count].notify = notify;
    subject->observers[subject->count].priv   = priv;
    subject->count++;
    return true;
}

void sensor_subject_detach(sensor_subject_t *subject,
                           observer_notify_fn notify)
{
    for (int i = 0; i < subject->count; i++) {
        if (subject->observers[i].notify == notify) {
            /* 把最后一个移到当前位置，实现删除 */
            subject->observers[i] = subject->observers[subject->count - 1];
            subject->count--;
            return;
        }
    }
}

void sensor_subject_notify(sensor_subject_t *subject,
                           const sensor_data_t *data)
{
    if (!subject || !data) return;

    printf("[Subject] 传感器数据更新 → 温度:%d.%d°C 湿度:%d.%d%%RH\n",
           data->temperature / 10, data->temperature % 10,
           data->humidity / 10, data->humidity % 10);

    for (int i = 0; i < subject->count; i++) {
        if (subject->observers[i].notify) {
            subject->observers[i].notify(subject->observers[i].priv, data);
        }
    }
}