/* observer.h */
#ifndef OBSERVER_H
#define OBSERVER_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_OBSERVERS  8     // 根据 MCU RAM 调整，通常 4~8 足够

/* 传感器数据（主题状态） */
typedef struct {
    int16_t  temperature;    // 单位：0.1°C，例如 256 = 25.6°C
    int16_t  humidity;       // 单位：0.1%RH
    uint32_t timestamp;
} sensor_data_t;

/* 观察者回调函数类型 */
typedef void (*observer_notify_fn)(void *observer_priv, const sensor_data_t *data);

/* 单个观察者 */
typedef struct {
    observer_notify_fn notify;     // 通知回调
    void *priv;                    // 观察者私有数据（如模块句柄）
} observer_t;

/* 主题（Subject） - 静态实现 */
typedef struct {
    observer_t observers[MAX_OBSERVERS];
    int count;
} sensor_subject_t;

/* 接口函数 */
void sensor_subject_init(sensor_subject_t *subject);
bool sensor_subject_attach(sensor_subject_t *subject, 
                           observer_notify_fn notify, 
                           void *priv);

void sensor_subject_detach(sensor_subject_t *subject, 
                           observer_notify_fn notify);

void sensor_subject_notify(sensor_subject_t *subject, 
                           const sensor_data_t *data);

#endif