/* sensor_iterator.c */
#include "sensor_iterator.h"
#include <stdio.h>

/* 迭代器私有数据 */
typedef struct {
    sensor_manager_t *mgr;
    int               current_index;
} sensor_iter_priv_t;

static bool sensor_has_next(iterator_t *it)
{
    sensor_iter_priv_t *priv = (sensor_iter_priv_t *)it->priv;
    return priv->current_index < priv->mgr->count;
}

static sensor_t sensor_next(iterator_t *it)
{
    sensor_iter_priv_t *priv = (sensor_iter_priv_t *)it->priv;
    if (priv->current_index >= priv->mgr->count) {
        sensor_t empty = {0};
        return empty;
    }
    return priv->mgr->sensors[priv->current_index++];
}

static void sensor_reset(iterator_t *it)
{
    sensor_iter_priv_t *priv = (sensor_iter_priv_t *)it->priv;
    priv->current_index = 0;
}

void sensor_manager_init(sensor_manager_t *mgr)
{
    mgr->count = 0;
    for (int i = 0; i < MAX_SENSORS; i++) {
        mgr->sensors[i].id = 0;
        mgr->sensors[i].type = SENSOR_TYPE_UNKNOWN;
        mgr->sensors[i].value = 0;
        mgr->sensors[i].status = 0;
        mgr->sensors[i].name = "N/A";
    }
}

bool sensor_manager_add(sensor_manager_t *mgr,
                        uint8_t id,
                        sensor_type_t type,
                        const char *name)
{
    if (mgr->count >= MAX_SENSORS)
        return false;

    mgr->sensors[mgr->count].id     = id;
    mgr->sensors[mgr->count].type   = type;
    mgr->sensors[mgr->count].value  = 0;
    mgr->sensors[mgr->count].status = 0;
    mgr->sensors[mgr->count].name   = name;
    mgr->count++;
    return true;
}

void sensor_manager_create_iterator(sensor_manager_t *mgr, iterator_t *it)
{
    static sensor_iter_priv_t priv;   // 静态私有数据（嵌入式常用）

    priv.mgr = mgr;
    priv.current_index = 0;

    it->has_next = sensor_has_next;
    it->next     = sensor_next;
    it->reset    = sensor_reset;
    it->priv     = &priv;
}