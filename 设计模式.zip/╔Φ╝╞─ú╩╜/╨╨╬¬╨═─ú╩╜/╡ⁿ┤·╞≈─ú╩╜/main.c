/* main.c */
#include "sensor_iterator.h"
#include <stdio.h>

int main(void)
{
    sensor_manager_t sensor_mgr;
    iterator_t it;

    sensor_manager_init(&sensor_mgr);

    /* 静态添加传感器（实际项目中可在初始化函数中完成） */
    sensor_manager_add(&sensor_mgr, 1, SENSOR_TYPE_TEMP,     "温度传感器1");
    sensor_manager_add(&sensor_mgr, 2, SENSOR_TYPE_HUMID,    "湿度传感器");
    sensor_manager_add(&sensor_mgr, 3, SENSOR_TYPE_PRESSURE, "压力传感器");
    sensor_manager_add(&sensor_mgr, 4, SENSOR_TYPE_VOLTAGE,  "电源电压");

    /* 创建迭代器 */
    sensor_manager_create_iterator(&sensor_mgr, &it);

    printf("=== 嵌入式迭代器模式 - 传感器遍历演示 ===\n\n");

    /* 使用迭代器遍历（客户端代码不关心内部存储方式） */
    it.reset(&it);
    while (it.has_next(&it)) {
        sensor_t s = it.next(&it);
        printf("ID:%2d  类型:%d  名称:%s  值:%d  状态:%d\n",
               s.id, s.type, s.name, s.value, s.status);
    }

    printf("\n=== 再次遍历（重置迭代器） ===\n");
    it.reset(&it);
    while (it.has_next(&it)) {
        sensor_t s = it.next(&it);
        /* 模拟读取真实值 */
        s.value = (s.id * 100) + 50;   // 示例
        printf("[读取] %s 当前值 = %d\n", s.name, s.value);
    }

    return 0;
}