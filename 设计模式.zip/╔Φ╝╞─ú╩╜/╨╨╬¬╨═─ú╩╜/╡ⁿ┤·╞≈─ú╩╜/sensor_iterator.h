/* sensor_iterator.h */
#ifndef SENSOR_ITERATOR_H
#define SENSOR_ITERATOR_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_SENSORS  12     // 根据 MCU 资源调整

/* 传感器类型 */
typedef enum {
    SENSOR_TYPE_TEMP,
    SENSOR_TYPE_HUMID,
    SENSOR_TYPE_PRESSURE,
    SENSOR_TYPE_VOLTAGE,
    SENSOR_TYPE_UNKNOWN
} sensor_type_t;

/* 单个传感器数据 */
typedef struct {
    uint8_t         id;
    sensor_type_t   type;
    int16_t         value;      // 原始值（根据类型有不同单位）
    uint8_t         status;     // 0=正常, 1=故障, 2=离线
    const char*     name;       // 传感器名称（Flash 中字符串）
} sensor_t;

/* 迭代器接口（核心） */
typedef struct iterator {
    bool     (*has_next)(struct iterator *it);
    sensor_t (*next)(struct iterator *it);      // 返回当前元素并移动到下一个
    void     (*reset)(struct iterator *it);     // 重置迭代器
    void*    priv;                              // 迭代器私有数据
} iterator_t;

/* 传感器容器（聚合对象） - 静态实现 */
typedef struct {
    sensor_t sensors[MAX_SENSORS];
    int      count;
} sensor_manager_t;

/* 接口函数 */
void sensor_manager_init(sensor_manager_t *mgr);

/* 添加传感器（嵌入式中通常在初始化时静态添加） */
bool sensor_manager_add(sensor_manager_t *mgr,
                        uint8_t id,
                        sensor_type_t type,
                        const char *name);

/* 创建迭代器 */
void sensor_manager_create_iterator(sensor_manager_t *mgr, iterator_t *it);

#endif