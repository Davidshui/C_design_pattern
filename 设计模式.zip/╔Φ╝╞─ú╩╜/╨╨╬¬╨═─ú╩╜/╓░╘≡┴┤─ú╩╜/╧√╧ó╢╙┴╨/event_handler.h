/* event_handler.h */
#ifndef EVENT_HANDLER_H
#define EVENT_HANDLER_H

#include <stdint.h>
#include <stdbool.h>

/* ==================== 事件定义 ==================== */
typedef enum {
    EVENT_TYPE_SENSOR = 1,
    EVENT_TYPE_BUTTON,
    EVENT_TYPE_ERROR,
    EVENT_TYPE_COMMAND,
    EVENT_TYPE_LOG,
    EVENT_TYPE_UNKNOWN
} event_type_t;

typedef enum {
    PRIORITY_HIGH   = 0,
    PRIORITY_NORMAL = 1,
    PRIORITY_LOW    = 2
} event_priority_t;

typedef struct {
    event_type_t     type;
    event_priority_t priority;
    uint32_t         timestamp;
    void*            data;
    uint32_t         data_len;
} event_t;

/* ==================== 静态职责链 ==================== */
#define MAX_HANDLERS  8     /* 根据 MCU RAM 调整，建议 4~8 */

typedef struct {
    bool (*can_handle)(void *priv, const event_t *event);
    bool (*handle)(void *priv, event_t *event);
    void *priv;                     /* 处理者私有数据 */
} handler_t;

/* 职责链管理结构（静态） */
typedef struct {
    handler_t handlers[MAX_HANDLERS];   /* 静态数组 */
    int       count;                    /* 当前注册的 Handler 数量 */
} handler_chain_t;

/* 接口函数 */
void handler_chain_init(handler_chain_t *chain);
bool handler_chain_add(handler_chain_t *chain,
                       bool (*can_handle)(void*, const event_t*),
                       bool (*handle)(void*, event_t*),
                       void *priv);

bool handler_chain_process(handler_chain_t *chain, event_t *event);

#endif