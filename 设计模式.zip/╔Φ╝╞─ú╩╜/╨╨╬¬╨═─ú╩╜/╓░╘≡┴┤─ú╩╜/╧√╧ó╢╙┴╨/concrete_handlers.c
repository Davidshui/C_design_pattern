/* concrete_handlers.c */
#include "event_handler.h"
#include <stdio.h>

/* ------------------- 错误处理者（高优先级） ------------------- */
typedef struct {
    int error_count;
} error_priv_t;

static bool error_can_handle(void *priv, const event_t *event)
{
    (void)priv;
    return (event->type == EVENT_TYPE_ERROR) && 
           (event->priority == PRIORITY_HIGH);
}

static bool error_handle(void *priv, event_t *event)
{
    error_priv_t *p = (error_priv_t *)priv;
    p->error_count++;
    printf("[ErrorHandler] *** 高优先级错误！计数=%d ***\n", p->error_count);
    return true;        /* 终止传递 */
}

/* ------------------- 传感器处理者 ------------------- */
static bool sensor_can_handle(void *priv, const event_t *event)
{
    (void)priv;
    return event->type == EVENT_TYPE_SENSOR;
}

static bool sensor_handle(void *priv, event_t *event)
{
    (void)priv;
    printf("[SensorHandler] 处理传感器数据: %p\n", event->data);
    return false;       /* 继续传递给后续（如日志） */
}

/* ------------------- 日志处理者（兜底） ------------------- */
static bool log_can_handle(void *priv, const event_t *event)
{
    (void)priv;
    (void)event;
    return true;        /* 记录所有剩余事件 */
}

static bool log_handle(void *priv, event_t *event)
{
    (void)priv;
    printf("[LogHandler] 记录事件 类型:%d 优先级:%d\n", 
           event->type, event->priority);
    return true;
}