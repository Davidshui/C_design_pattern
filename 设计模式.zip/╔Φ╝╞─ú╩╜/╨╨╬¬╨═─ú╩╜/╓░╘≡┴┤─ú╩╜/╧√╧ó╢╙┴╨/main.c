/* main.c */




/**
如何在真实 MCU 项目中使用:

在系统初始化阶段调用 handler_chain_add 注册所有模块的 Handler。
消息队列任务中循环取出 event_t，调用 handler_chain_process(&chain, &evt)。
根据优先级调整注册顺序（高优先级放前面）
*/
#include "event_handler.h"
#include <stdio.h>

/* 静态私有数据（嵌入式常用） */
static error_priv_t error_priv = { .error_count = 0 };

int main(void)
{
    handler_chain_t chain;
    handler_chain_init(&chain);

    /* 注册处理者（顺序即优先级：高优先级错误 → 传感器 → 日志） */
    handler_chain_add(&chain, error_can_handle, error_handle, &error_priv);
    handler_chain_add(&chain, sensor_can_handle, sensor_handle, NULL);
    handler_chain_add(&chain, log_can_handle,    log_handle,    NULL);

    printf("=== 静态职责链 - 消息队列事件处理演示 ===\n\n");

    /* 模拟从消息队列取出的几个事件 */
    event_t events[4] = {
        { EVENT_TYPE_ERROR,   PRIORITY_HIGH,   1000, (void*)0xEE01, 0 },
        { EVENT_TYPE_SENSOR,  PRIORITY_NORMAL, 1001, (void*)0x1234, 8 },
        { EVENT_TYPE_BUTTON,  PRIORITY_LOW,    1002, (void*)0xABCD, 4 },
        { EVENT_TYPE_SENSOR,  PRIORITY_NORMAL, 1003, (void*)0x5678, 8 },
    };

    for (int i = 0; i < 4; i++) {
        printf("--- 处理事件 %d ---\n", i+1);
        handler_chain_process(&chain, &events[i]);
        printf("\n");
    }

    return 0;
}