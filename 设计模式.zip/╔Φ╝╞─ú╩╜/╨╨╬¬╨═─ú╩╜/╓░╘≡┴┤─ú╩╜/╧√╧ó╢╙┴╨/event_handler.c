/* event_handler.c */
#include "event_handler.h"
#include <stdio.h>

void handler_chain_init(handler_chain_t *chain)
{
    chain->count = 0;
    /* 可选：把所有槽位清零 */
    for (int i = 0; i < MAX_HANDLERS; i++) {
        chain->handlers[i].can_handle = NULL;
        chain->handlers[i].handle     = NULL;
        chain->handlers[i].priv       = NULL;
    }
}

bool handler_chain_add(handler_chain_t *chain,
                       bool (*can_handle)(void*, const event_t*),
                       bool (*handle)(void*, event_t*),
                       void *priv)
{
    if (chain->count >= MAX_HANDLERS)
        return false;               /* 链已满 */

    handler_t *h = &chain->handlers[chain->count++];
    h->can_handle = can_handle;
    h->handle     = handle;
    h->priv       = priv;
    return true;
}

bool handler_chain_process(handler_chain_t *chain, event_t *event)
{
    if (!chain || !event)
        return false;

    printf("[Chain] 事件流动开始 → 类型:%d 优先级:%d\n", 
           event->type, event->priority);

    for (int i = 0; i < chain->count; i++) {
        handler_t *h = &chain->handlers[i];
        if (h->can_handle && h->can_handle(h->priv, event)) {
            
            bool handled = false;
            if (h->handle)
                handled = h->handle(h->priv, event);

            printf("[Chain]   → Handler[%d] 处理%s\n", i, handled ? "（终止）" : "（继续）");

            if (handled)
                return true;        /* 事件被完全处理，停止流动 */
        }
    }

    printf("[Chain]   → 无处理者认领该事件\n");
    return false;
}