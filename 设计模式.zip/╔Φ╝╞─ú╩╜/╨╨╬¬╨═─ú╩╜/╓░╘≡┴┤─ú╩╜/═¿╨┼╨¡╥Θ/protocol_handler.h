/* protocol_handler.h */
#ifndef PROTOCOL_HANDLER_H
#define PROTOCOL_HANDLER_H

#include <stdint.h>
#include <stdbool.h>

/* ==================== 帧定义（简化示例） ==================== */
#define MAX_FRAME_SIZE  64

typedef struct {
    uint8_t  magic;           // 帧头魔数，例如 0xAA
    uint8_t  cmd;             // 命令码
    uint8_t  len;             // 数据长度
    uint8_t  data[MAX_FRAME_SIZE - 5];  // 数据域（简化）
    uint16_t crc;             // CRC16（简化存放）
} frame_t;

/* ==================== 静态职责链 ==================== */
#define MAX_PROTOCOL_HANDLERS  6   /* 根据需要调整，通常 4~6 足够 */

typedef struct {
    bool (*can_handle)(void *priv, const frame_t *frame);
    bool (*handle)(void *priv, frame_t *frame);   /* 返回 true 表示已完全处理 */
    void *priv;
} protocol_handler_t;

typedef struct {
    protocol_handler_t handlers[MAX_PROTOCOL_HANDLERS];
    int count;
} protocol_chain_t;

/* 接口函数 */
void protocol_chain_init(protocol_chain_t *chain);
bool protocol_chain_add(protocol_chain_t *chain,
                        bool (*can_handle)(void*, const frame_t*),
                        bool (*handle)(void*, frame_t*),
                        void *priv);

bool protocol_chain_parse(protocol_chain_t *chain, frame_t *frame);

#endif
