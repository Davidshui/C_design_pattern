/* protocol_handler.c */
#include "protocol_handler.h"
#include <stdio.h>

void protocol_chain_init(protocol_chain_t *chain)
{
    chain->count = 0;
    for (int i = 0; i < MAX_PROTOCOL_HANDLERS; i++) {
        chain->handlers[i].can_handle = NULL;
        chain->handlers[i].handle     = NULL;
        chain->handlers[i].priv       = NULL;
    }
}

bool protocol_chain_add(protocol_chain_t *chain,
                        bool (*can_handle)(void*, const frame_t*),
                        bool (*handle)(void*, frame_t*),
                        void *priv)
{
    if (chain->count >= MAX_PROTOCOL_HANDLERS)
        return false;

    protocol_handler_t *h = &chain->handlers[chain->count++];
    h->can_handle = can_handle;
    h->handle     = handle;
    h->priv       = priv;
    return true;
}

bool protocol_chain_parse(protocol_chain_t *chain, frame_t *frame)
{
    if (!chain || !frame) return false;

    printf("[Protocol Chain] 开始解析帧 (魔数=0x%02X, 命令=0x%02X)\n", 
           frame->magic, frame->cmd);

    for (int i = 0; i < chain->count; i++) {
        protocol_handler_t *h = &chain->handlers[i];
        if (h->can_handle && h->can_handle(h->priv, frame)) {
            bool handled = h->handle ? h->handle(h->priv, frame) : false;
            printf("[Protocol Chain]   → Handler[%d] 处理%s\n", 
                   i, handled ? "（完成，终止）" : "（继续传递）");
            if (handled)
                return true;
        }
    }

    printf("[Protocol Chain]   → 帧未被任何协议处理（丢弃）\n");
    return false;
}