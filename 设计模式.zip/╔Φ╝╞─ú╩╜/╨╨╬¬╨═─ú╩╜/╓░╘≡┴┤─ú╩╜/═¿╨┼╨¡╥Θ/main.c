/* main.c */
#include "protocol_handler.h"
#include <stdio.h>

static cmd_handler_priv_t cmd_priv = { .processed_count = 0 };

int main(void)
{
    protocol_chain_t chain;
    protocol_chain_init(&chain);

    /* 按解析顺序注册 Handler（从底层到上层） */
    protocol_chain_add(&chain, header_can_handle,  header_handle,  NULL);
    protocol_chain_add(&chain, crc_can_handle,    crc_handle,     NULL);
    protocol_chain_add(&chain, command_can_handle,command_handle, &cmd_priv);
    protocol_chain_add(&chain, error_can_handle,  error_handle,   NULL);

    printf("=== 嵌入式协议栈 - 职责链帧解析演示 ===\n\n");

    /* 模拟接收到的几帧数据 */
    frame_t frames[3] = {
        {0xAA, 0x01, 8, {0}, 0x1234},   // 有效读传感器命令
        {0xAA, 0xFF, 4, {0}, 0xABCD},   // 未知命令
        {0xBB, 0x05, 2, {0}, 0x0000}    // 非法帧头
    };

    for (int i = 0; i < 3; i++) {
        printf("--- 解析第 %d 帧 ---\n", i+1);
        protocol_chain_parse(&chain, &frames[i]);
        printf("\n");
    }

    printf("共处理有效命令 %u 条\n", cmd_priv.processed_count);
    return 0;
}