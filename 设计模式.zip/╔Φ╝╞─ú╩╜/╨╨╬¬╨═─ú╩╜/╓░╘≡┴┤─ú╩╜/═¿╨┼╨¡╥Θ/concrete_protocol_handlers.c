/* concrete_protocol_handlers.c */
#include "protocol_handler.h"
#include <stdio.h>

/* 示例私有数据 */
typedef struct {
    uint16_t processed_count;
} cmd_handler_priv_t;

/* ------------------- 1. 帧头校验 Handler ------------------- */
static bool header_can_handle(void *priv, const frame_t *frame)
{
    (void)priv;
    return frame->magic == 0xAA && frame->len < MAX_FRAME_SIZE;
}

static bool header_handle(void *priv, frame_t *frame)
{
    (void)priv;
    printf("[Header Handler] 帧头校验通过 (长度=%d)\n", frame->len);
    return false;   /* 继续向下校验 CRC 等 */
}

/* ------------------- 2. CRC 校验 Handler ------------------- */
static bool crc_can_handle(void *priv, const frame_t *frame)
{
    (void)priv;
    /* 简化：实际应计算 CRC，这里只演示结构 */
    return true;    /* 假设所有帧都经过简单检查 */
}

static bool crc_handle(void *priv, frame_t *frame)
{
    (void)priv;
    printf("[CRC Handler] CRC 校验通过\n");
    return false;   /* 继续向下识别协议 */
}

/* ------------------- 3. 命令处理 Handler ------------------- */
static bool command_can_handle(void *priv, const frame_t *frame)
{
    (void)priv;
    return (frame->cmd >= 0x01 && frame->cmd <= 0x7F);  /* 有效命令范围 */
}

static bool command_handle(void *priv, frame_t *frame)
{
    cmd_handler_priv_t *p = (cmd_handler_priv_t *)priv;
    p->processed_count++;

    switch (frame->cmd) {
        case 0x01:
            printf("[Command Handler] 执行读取传感器命令\n");
            break;
        case 0x02:
            printf("[Command Handler] 执行设置参数命令\n");
            break;
        default:
            printf("[Command Handler] 未知命令 0x%02X\n", frame->cmd);
            return false;
    }
    return true;   /* 命令已处理，终止链 */
}

/* ------------------- 4. 错误兜底 Handler ------------------- */
static bool error_can_handle(void *priv, const frame_t *frame)
{
    (void)priv;
    (void)frame;
    return true;   /* 兜底，处理所有剩余帧 */
}

static bool error_handle(void *priv, frame_t *frame)
{
    (void)priv;
    printf("[Error Handler] 非法帧或未识别命令 (魔数=0x%02X, 命令=0x%02X)\n",
           frame->magic, frame->cmd);
    return true;
}