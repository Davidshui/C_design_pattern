/* main.c */
/**
 * 流程固定：任何新音频类型（MP3、OGG、实时流）
 * 只需实现自己的 audio_ops 函数即可，无需修改模板流程。
 * 可以在 process_audio 中加入 FFT 滤波、均衡器等。
*/
#include "audio_processor.h"
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    struct audio_processor *wav_proc = create_wav_processor(6);  /* +6dB 增益 */

    printf("=== 处理音频流 ===\n");
    int ret = audio_processor_process(wav_proc, "input.wav", "output_processed.wav");

    if (ret == 0)
        printf("音频处理完成！输出文件: output_processed.wav\n");

    audio_processor_destroy(wav_proc);
    free(wav_proc);

    return 0;
}