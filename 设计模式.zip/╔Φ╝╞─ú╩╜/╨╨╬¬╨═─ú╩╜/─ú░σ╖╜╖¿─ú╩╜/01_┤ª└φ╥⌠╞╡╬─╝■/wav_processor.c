/* wav_processor.c */
#include "audio_processor.h"
#include <stdlib.h>
#include <string.h>

struct wav_priv {
    int gain_db;        /* 示例私有配置：音量增益（dB） */
};

/* 简化 WAV 头（实际使用时需完整解析 RIFF 头） */
static FILE *wav_open(void *priv, const char *filename, struct audio_info *info)
{
    (void)priv;
    printf("[WAV] 打开文件: %s\n", filename);
    FILE *fp = fopen(filename, "rb");
    if (fp) {
        /* 跳过简化头，实际应解析 WAV 头 */
        fseek(fp, 44, SEEK_SET);   /* 跳过标准 WAV 头 44 字节 */
        info->sample_rate = 44100;
        info->channels = 1;        /* 假设单声道 */
        info->bits_per_sample = 16;
    }
    return fp;
}

static int wav_decode(void *priv, FILE *fp, short *pcm_buffer, size_t *frames)
{
    (void)priv;
    printf("[WAV] 读取 PCM 数据...\n");
    *frames = fread(pcm_buffer, sizeof(short), 4096, fp);  /* 简化：一次读一批 */
    return (*frames > 0) ? 0 : -1;
}

static int wav_process(void *priv, short *pcm_buffer, size_t frames)
{
    struct wav_priv *p = priv;
    printf("[WAV] 音频处理：应用增益 %d dB\n", p->gain_db);

    /* 简单音量调整（防止溢出） */
    for (size_t i = 0; i < frames; i++) {
        int sample = pcm_buffer[i];
        sample = sample * 2;                 /* 示例：简单放大 */
        if (sample > 32767) sample = 32767;
        if (sample < -32768) sample = -32768;
        pcm_buffer[i] = (short)sample;
    }
    return 0;
}

static int wav_save(void *priv, const short *pcm_buffer, size_t frames, const char *output_path)
{
    (void)priv;
    printf("[WAV] 保存到: %s (帧数: %zu)\n", output_path, frames);
    FILE *out = fopen(output_path, "wb");
    if (!out) return -1;
    /* 简化：仅写 PCM 数据，实际应写完整 WAV 头 */
    fwrite(pcm_buffer, sizeof(short), frames, out);
    fclose(out);
    return 0;
}

static void wav_log(void *priv, const char *step)
{
    struct wav_priv *p = priv;
    printf("[WAV Gain=%d] %s\n", p->gain_db, step);
}

static void wav_cleanup(void *priv)
{
    free(priv);
}

/* 创建 WAV 音频处理器 */
struct audio_processor *create_wav_processor(int gain_db)
{
    struct audio_processor *proc = malloc(sizeof(*proc));
    struct wav_priv *priv = malloc(sizeof(*priv));

    if (!proc || !priv) {
        free(proc);
        free(priv);
        return NULL;
    }

    priv->gain_db = gain_db;

    static const struct audio_ops wav_ops = {
        .open_audio      = wav_open,
        .decode_audio    = wav_decode,
        .process_audio   = wav_process,
        .encode_and_save = wav_save,
        .log_step        = wav_log,
        .cleanup         = wav_cleanup,
    };

    proc->ops = &wav_ops;
    proc->priv = priv;
    proc->name = "WAV Audio Processor";
    return proc;
}
