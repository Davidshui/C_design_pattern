/* audio_processor.h */
#ifndef AUDIO_PROCESSOR_H
#define AUDIO_PROCESSOR_H

#include <stdio.h>
#include <stddef.h>

/* 音频格式信息（简化） */
struct audio_info {
    int sample_rate;    /* 采样率，例如 44100 */
    int channels;       /* 通道数，1=单声道，2=立体声 */
    int bits_per_sample;/* 位深，16 或 32 */
};

/* 可变步骤的操作函数表（vtable） */
struct audio_ops {
    /* 必须实现的 Primitive Operations */
    FILE *(*open_audio)(void *priv, const char *filename, struct audio_info *info);
    int   (*decode_audio)(void *priv, FILE *fp, short *pcm_buffer, size_t *frames);  /* 返回读取的帧数 */
    int   (*process_audio)(void *priv, short *pcm_buffer, size_t frames);
    int   (*encode_and_save)(void *priv, const short *pcm_buffer, size_t frames, const char *output_path);

    /* 可选 Hook 方法 */
    void  (*log_step)(void *priv, const char *step);
    void  (*cleanup)(void *priv);
};

/* 音频处理器（模板基类） */
struct audio_processor {
    const struct audio_ops *ops;
    void *priv;
    const char *name;
};

/* 模板方法：固定的音频处理流程 */
int audio_processor_process(struct audio_processor *proc,
                            const char *input_file,
                            const char *output_file);

void audio_processor_destroy(struct audio_processor *proc);

#endif