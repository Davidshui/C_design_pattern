/* audio_processor.c */
#include "audio_processor.h"
#include <stdlib.h>
#include <string.h>

static void default_log(void *priv, const char *step)
{
    (void)priv;
    printf("[AudioProcessor] %s\n", step);
}

static void default_cleanup(void *priv)
{
    (void)priv;
}

int audio_processor_process(struct audio_processor *proc,
                            const char *input_file,
                            const char *output_file)
{
    if (!proc || !proc->ops)
        return -1;

    FILE *fp = NULL;
    short *pcm_buffer = NULL;
    struct audio_info info = {0};
    size_t frames = 0;
    int ret = 0;
    const size_t BUFFER_FRAMES = 4096;   /* 每次处理 4096 帧（可调整） */

    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "=== 开始音频处理流程 ===");

    /* 步骤1：打开音频 */
    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "正在打开音频文件...");
    fp = proc->ops->open_audio(proc->priv, input_file, &info);
    if (!fp) {
        fprintf(stderr, "Error: Failed to open audio %s\n", input_file);
        return -1;
    }

    pcm_buffer = malloc(BUFFER_FRAMES * info.channels * sizeof(short));
    if (!pcm_buffer) goto cleanup;

    /* 步骤2：解码/读取音频数据 */
    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "正在解码音频数据...");
    ret = proc->ops->decode_audio(proc->priv, fp, pcm_buffer, &frames);
    if (ret != 0 || frames == 0) goto cleanup;

    /* 步骤3：业务处理（音量调整、滤波等） */
    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "正在处理音频（音量归一化等）...");
    ret = proc->ops->process_audio(proc->priv, pcm_buffer, frames);
    if (ret != 0) goto cleanup;

    /* 步骤4：编码并保存 */
    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "正在保存处理后的音频...");
    ret = proc->ops->encode_and_save(proc->priv, pcm_buffer, frames, output_file);

cleanup:
    if (fp) fclose(fp);
    free(pcm_buffer);

    if (proc->ops->cleanup)
        proc->ops->cleanup(proc->priv);

    if (proc->ops->log_step)
        proc->ops->log_step(proc->priv, "=== 音频处理流程结束 ===");

    return ret;
}

void audio_processor_destroy(struct audio_processor *proc)
{
    if (proc && proc->ops && proc->ops->cleanup)
        proc->ops->cleanup(proc->priv);
}