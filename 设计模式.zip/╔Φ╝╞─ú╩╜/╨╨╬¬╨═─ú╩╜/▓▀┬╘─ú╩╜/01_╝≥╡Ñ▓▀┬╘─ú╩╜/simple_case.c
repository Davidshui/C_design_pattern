#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 使用函数指针数组优化策略调用
typedef enum {
    OP_ADD,
    OP_SUBTRACT,
    OP_MULTIPLY,
    OP_DIVIDE
} operation_e;

typedef double (*math_func)(double a, double b);

double add(double a, double b) { return a + b; }
double subtract(double a, double b) { return a - b; }
double multiply(double a, double b) { return a * b; }
double divide(double a, double b) { return a / b; }

math_func math_ops[] = {add, subtract, multiply, divide};

double calculate(operation_e op, double a, double b) {
    if (op >= 0 && op < sizeof(math_ops)/sizeof(math_ops[0])) {
        return math_ops[op](a, b);
    }
    return 0;
}