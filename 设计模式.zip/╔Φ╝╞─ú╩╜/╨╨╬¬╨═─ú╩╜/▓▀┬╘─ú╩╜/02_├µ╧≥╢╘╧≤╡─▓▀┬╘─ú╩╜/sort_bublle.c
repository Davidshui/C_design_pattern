#include "strategy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ====================== 冒泡排序策略 ====================== */
struct bubble_priv {
    int max_passes;        /* 最多执行多少轮（优化用） */
};

static void bubble_sort_impl(void *priv, int *arr, size_t len)
{
    struct bubble_priv *p = priv;
    int passes = 0;

    printf("[Bubble Sort] 开始排序 (max_passes=%d)\n", p->max_passes);

    for (size_t i = 0; i < len - 1 && passes < p->max_passes; i++) {
        int swapped = 0;
        for (size_t j = 0; j < len - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = 1;
            }
        }
        passes++;
        if (!swapped) break;   /* 提前结束优化 */
    }
}

static const char *bubble_get_name(void *priv)
{
    (void)priv;
    return "Bubble Sort";
}

static void bubble_destroy(void *priv)
{
    free(priv);
}

struct sort_strategy *create_bubble_strategy(int max_passes)
{
    struct sort_strategy *strat = malloc(sizeof(*strat));
    struct bubble_priv *priv = malloc(sizeof(*priv));

    if (!strat || !priv) {
        free(strat);
        free(priv);
        return NULL;
    }

    priv->max_passes = max_passes;

    static const struct sort_ops bubble_ops = {
        .sort      = bubble_sort_impl,
        .get_name  = bubble_get_name,
        .destroy   = bubble_destroy,
    };

    strat->ops = &bubble_ops;
    strat->priv = priv;
    return strat;
}