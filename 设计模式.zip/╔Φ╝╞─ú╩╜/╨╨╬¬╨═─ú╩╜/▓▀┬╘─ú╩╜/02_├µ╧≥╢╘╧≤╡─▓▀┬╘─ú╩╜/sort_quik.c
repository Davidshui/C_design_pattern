#include "strategy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



/* ====================== 快速排序策略 ====================== */
struct quick_priv {
    int threshold;         /* 小于此长度时切换为插入排序（混合排序） */
};

static void quick_sort_impl(void *priv, int *arr, size_t len)
{
    struct quick_priv *p = priv;
    printf("[Quick Sort] 开始排序 (threshold=%d)\n", p->threshold);

    /* 这里调用标准库 qsort 演示，实际项目中可自行实现带阈值的混合快速排序 */
    qsort(arr, len, sizeof(int), 
          (int (*)(const void *, const void *)) 
          (int (*)(const int *, const int *)) 
          ([](const int *a, const int *b){ return *a - *b; }));
}

static const char *quick_get_name(void *priv)
{
    (void)priv;
    return "Quick Sort (with hybrid threshold)";
}

static void quick_destroy(void *priv)
{
    free(priv);
}

struct sort_strategy *create_quick_strategy(int threshold)
{
    struct sort_strategy *strat = malloc(sizeof(*strat));
    struct quick_priv *priv = malloc(sizeof(*priv));

    if (!strat || !priv) {
        free(strat);
        free(priv);
        return NULL;
    }

    priv->threshold = threshold;

    static const struct sort_ops quick_ops = {
        .sort      = quick_sort_impl,
        .get_name  = quick_get_name,
        .destroy   = quick_destroy,
    };

    strat->ops = &quick_ops;
    strat->priv = priv;
    return strat;
}