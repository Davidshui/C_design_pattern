#include "strategy.h"
#include <stdio.h>
#include <stdlib.h>

void sorter_init(struct sorter *s)
{
    s->strategy = NULL;
}

void sorter_set_strategy(struct sorter *s, struct sort_strategy *strategy)
{
    /* 释放旧策略的私有数据 */
    if (s->strategy && s->strategy->ops && s->strategy->ops->destroy)
        s->strategy->ops->destroy(s->strategy->priv);

    s->strategy = strategy;
}

void sorter_sort(struct sorter *s, int *arr, size_t len)
{
    if (!s->strategy || !s->strategy->ops || !s->strategy->ops->sort) {
        fprintf(stderr, "Error: No sorting strategy set!\n");
        return;
    }

    s->strategy->ops->sort(s->strategy->priv, arr, len);
}

const char *sorter_get_strategy_name(struct sorter *s)
{
    if (!s->strategy || !s->strategy->ops || !s->strategy->ops->get_name)
        return "unknown";

    return s->strategy->ops->get_name(s->strategy->priv);
}

void sorter_destroy(struct sorter *s)
{
    if (s->strategy && s->strategy->ops && s->strategy->ops->destroy)
        s->strategy->ops->destroy(s->strategy->priv);

    s->strategy = NULL;
}