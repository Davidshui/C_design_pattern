/* strategy.h */
#ifndef SORT_STRATEGY_H
#define SORT_STRATEGY_H

#include <stddef.h>

/* 排序策略的操作函数表（vtable） */
struct sort_ops {
    /* 执行排序 */
    void (*sort)(void *priv, int *arr, size_t len);
    
    /* 获取策略名称（用于调试） */
    const char *(*get_name)(void *priv);
    
    /* 销毁策略私有数据 */
    void (*destroy)(void *priv);
};

/* 策略结构体 */
struct sort_strategy {
    const struct sort_ops *ops;
    void *priv;
};

/* 上下文（Sorter） */
struct sorter {
    struct sort_strategy *strategy;
};

void sorter_init(struct sorter *s);
void sorter_set_strategy(struct sorter *s, struct sort_strategy *strategy);
void sorter_sort(struct sorter *s, int *arr, size_t len);
const char *sorter_get_strategy_name(struct sorter *s);
void sorter_destroy(struct sorter *s);

struct sort_strategy *create_quick_strategy(int threshold);
struct sort_strategy *create_bubble_strategy(int max_passes);
#endif