/* main.c */
#include "strategy.h"
#include <stdio.h>

static void print_array(const int *arr, size_t len)
{
    for (size_t i = 0; i < len; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main(void)
{
    struct sorter s;
    int arr1[] = {64, 34, 25, 12, 22, 11, 90, 88, 45};
    int arr2[] = {64, 34, 25, 12, 22, 11, 90, 88, 45};
    size_t n = sizeof(arr1) / sizeof(arr1[0]);

    sorter_init(&s);

    /* 使用冒泡排序策略 */
    struct sort_strategy *bubble = create_bubble_strategy(100);
    sorter_set_strategy(&s, bubble);

    printf("当前策略: %s\n", sorter_get_strategy_name(&s));
    sorter_sort(&s, arr1, n);
    printf("排序结果: ");
    print_array(arr1, n);

    /* 切换为快速排序策略 */
    struct sort_strategy *quick = create_quick_strategy(16);
    sorter_set_strategy(&s, quick);

    printf("\n当前策略: %s\n", sorter_get_strategy_name(&s));
    sorter_sort(&s, arr2, n);
    printf("排序结果: ");
    print_array(arr2, n);

    sorter_destroy(&s);

    /* 释放策略结构体本身（priv 已在 destroy 中释放） */
    free(bubble);
    free(quick);

    return 0;
}