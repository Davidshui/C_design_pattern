#include "basic_led.h"
#include <stdio.h>

typedef struct {
    led_t* wrapped;        // 被装饰的对象
} logging_data_t;

static void logging_init(led_t* self)
{
    logging_data_t* data = (logging_data_t*)self->private_data;
    printf("【Logging Decorator】初始化完成\n");
    // 可以在这里对被装饰对象进行额外初始化
    data->wrapped->init(data->wrapped);
}

static void logging_on(led_t* self)
{
    logging_data_t* data = (logging_data_t*)self->private_data;
    printf("【Logging】→ 准备点亮\n");
    data->wrapped->on(data->wrapped);
    printf("【Logging】← 点亮完成\n");
}

static void logging_off(led_t* self)
{
    logging_data_t* data = (logging_data_t*)self->private_data;
    printf("【Logging】→ 准备熄灭\n");
    data->wrapped->off(data->wrapped);
    printf("【Logging】← 熄灭完成\n");
}

static void logging_toggle(led_t* self)
{
    logging_data_t* data = (logging_data_t*)self->private_data;
    printf("【Logging】→ 准备翻转\n");
    data->wrapped->toggle(data->wrapped);
}

static void logging_destroy(led_t* self)
{
    printf("【Logging Decorator】已释放\n");
}

void init_logging_decorator(led_t* decorator, 
                            logging_data_t* data, 
                            led_t* wrapped_led)
{
    data->wrapped = wrapped_led;

    decorator->private_data = data;
    decorator->init    = logging_init;
    decorator->on      = logging_on;
    decorator->off     = logging_off;
    decorator->toggle  = logging_toggle;
    decorator->destroy = logging_destroy;

    // 调用自身的 init 接口
    decorator->init(decorator);
}