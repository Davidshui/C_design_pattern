#include "basic_led.h"
#include <stdio.h>

typedef struct {
    uint8_t pin;
    uint8_t is_on;
} basic_led_data_t;

static void basic_led_init(led_t* self)
{
    basic_led_data_t* data = (basic_led_data_t*)self->private_data;
    data->is_on = 0;
    printf("【Basic LED】初始化完成，引脚 = %d\n", data->pin);
}

static void basic_led_on(led_t* self)
{
    basic_led_data_t* data = (basic_led_data_t*)self->private_data;
    data->is_on = 1;
    printf("【Basic LED】引脚 %d 已点亮\n", data->pin);
}

static void basic_led_off(led_t* self)
{
    basic_led_data_t* data = (basic_led_data_t*)self->private_data;
    data->is_on = 0;
    printf("【Basic LED】引脚 %d 已熄灭\n", data->pin);
}

static void basic_led_toggle(led_t* self)
{
    basic_led_data_t* data = (basic_led_data_t*)self->private_data;
    data->is_on = !data->is_on;
    printf("【Basic LED】引脚 %d 已翻转\n", data->pin);
}

static void basic_led_destroy(led_t* self)
{
    printf("【Basic LED】资源已释放\n");
}

// 初始化基础LED
void init_basic_led(led_t* led, basic_led_data_t* data, uint8_t pin)
{
    data->pin = pin;
    data->is_on = 0;

    led->private_data = data;
    led->init    = basic_led_init;
    led->on      = basic_led_on;
    led->off     = basic_led_off;
    led->toggle  = basic_led_toggle;
    led->destroy = basic_led_destroy;

    // 调用自身的 init 接口
    led->init(led);
}