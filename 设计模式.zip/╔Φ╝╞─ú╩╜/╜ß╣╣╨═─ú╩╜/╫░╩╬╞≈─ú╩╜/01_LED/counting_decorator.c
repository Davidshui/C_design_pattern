#include "basic_led.h"
#include <stdio.h>

typedef struct {
    led_t* wrapped;         // 被装饰的对象
    uint32_t on_count;
    uint32_t off_count;
    uint32_t toggle_count;
} counting_data_t;

static void counting_init(led_t* self)
{
    counting_data_t* data = (counting_data_t*)self->private_data;
    data->on_count = 0;
    data->off_count = 0;
    data->toggle_count = 0;
    printf("【Counting Decorator】初始化完成（计数清零）\n");
    data->wrapped->init(data->wrapped);   // 向下传递初始化
}

static void counting_on(led_t* self)
{
    counting_data_t* data = (counting_data_t*)self->private_data;
    data->on_count++;
    printf("【Counting】点亮计数: %u\n", data->on_count);
    data->wrapped->on(data->wrapped);
}

static void counting_off(led_t* self)
{
    counting_data_t* data = (counting_data_t*)self->private_data;
    data->off_count++;
    printf("【Counting】熄灭计数: %u\n", data->off_count);
    data->wrapped->off(data->wrapped);
}

static void counting_toggle(led_t* self)
{
    counting_data_t* data = (counting_data_t*)self->private_data;
    data->toggle_count++;
    printf("【Counting】翻转计数: %u\n", data->toggle_count);
    data->wrapped->toggle(data->wrapped);
}

static void counting_destroy(led_t* self)
{
    counting_data_t* data = (counting_data_t*)self->private_data;
    printf("【Counting Decorator】释放 - 点亮:%u  熄灭:%u  翻转:%u\n", 
           data->on_count, data->off_count, data->toggle_count);
}

void init_counting_decorator(led_t* decorator, 
                             counting_data_t* data, 
                             led_t* wrapped_led)
{
    data->wrapped = wrapped_led;
    data->on_count = 0;
    data->off_count = 0;
    data->toggle_count = 0;

    decorator->private_data = data;
    decorator->init    = counting_init;
    decorator->on      = counting_on;
    decorator->off     = counting_off;
    decorator->toggle  = counting_toggle;
    decorator->destroy = counting_destroy;

    decorator->init(decorator);   // 调用自身init
}