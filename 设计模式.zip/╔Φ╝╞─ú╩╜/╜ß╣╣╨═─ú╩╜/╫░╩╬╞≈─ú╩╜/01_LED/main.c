#include "basic_led.h"
#include <stdio.h>

// 调用者提供所有内存
static led_t basic_led;
static basic_led_data_t basic_data;

static led_t logging_led;
static logging_data_t logging_data;

static led_t counting_led;
static counting_data_t counting_data;

int main(void)
{
    printf("=== 嵌入式C 装饰模式演示（带 init 接口 + 多层装饰） ===\n\n");

    // 1. 初始化基础LED
    init_basic_led(&basic_led, &basic_data, 5);

    // 2. 日志装饰器包装基础LED
    init_logging_decorator(&logging_led, &logging_data, &basic_led);

    // 3. 计数装饰器再包装日志装饰器（多层装饰）
    init_counting_decorator(&counting_led, &counting_data, &logging_led);

    printf("\n=== 执行LED操作 ===\n");
    counting_led.on(&counting_led);
    counting_led.off(&counting_led);
    counting_led.toggle(&counting_led);
    counting_led.on(&counting_led);

    printf("\n=== 清理资源（从外层到内层） ===\n");
    counting_led.destroy(&counting_led);
    logging_led.destroy(&logging_led);
    basic_led.destroy(&basic_led);

    return 0;
}