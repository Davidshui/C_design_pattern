#ifndef BASIC_LED_H
#define BASIC_LED_H

#include <stdint.h>

// LED统一接口（包含 init 接口）
typedef struct led {
    void (*init)(struct led* self);      // 初始化接口
    void (*on)(struct led* self);
    void (*off)(struct led* self);
    void (*toggle)(struct led* self);
    void (*destroy)(struct led* self);

    void* private_data;
} led_t;

#endif