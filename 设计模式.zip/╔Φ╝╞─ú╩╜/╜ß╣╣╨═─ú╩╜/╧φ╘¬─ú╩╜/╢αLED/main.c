// main.c
/**
内存对比（享元模式优势）

不使用享元：每个LED都要保存blink_interval、update函数指针等 → 32个LED占用较多RAM
使用享元：只有 4个享元对象 共享内部状态，32个LED只保存指针 + GPIO信息 → 内存大幅减少

享元模式核心：把不变的、大量重复的“内部状态”抽取出来共享，只保留每个对象独有的“外部状态”。
*/
#include "flyweight.h"
#include "led_context.h"

// 静态分配所有LED上下文（外部状态）
static led_context_t leds[32];

int main(void)
{
    led_flyweight_init_all();

    // 初始化32个LED，只需要指定不同的外部状态（引脚）和共享的享元类型
    led_context_init(&leds[0],  &led_type_constant,    GPIOA, GPIO_PIN_0);
    led_context_init(&leds[1],  &led_type_slow_blink,  GPIOA, GPIO_PIN_1);
    led_context_init(&leds[2],  &led_type_fast_blink,  GPIOA, GPIO_PIN_2);
    led_context_init(&leds[3],  &led_type_breathing,   GPIOA, GPIO_PIN_3);
    
    // 后面继续初始化其余LED...
    for (int i = 4; i < 32; i++) {
        led_context_init(&leds[i], &led_type_slow_blink, GPIOB, i);
    }

    uint32_t tick = 0;
    while (1) {
        tick = HAL_GetTick();

        // 更新所有LED（享元模式下，行为逻辑是共享的）
        for (int i = 0; i < 32; i++) {
            led_context_update(&leds[i], tick);
        }

        HAL_Delay(10);
    }
}