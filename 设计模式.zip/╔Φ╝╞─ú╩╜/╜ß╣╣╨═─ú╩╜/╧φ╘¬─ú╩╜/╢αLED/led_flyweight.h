#ifndef LED_FLYWEIGHT_H
#define LED_FLYWEIGHT_H

#include <stdint.h>

// 共享的内部状态（享元对象）
typedef struct led_flyweight led_flyweight_t;

struct led_flyweight {
    const char *name;                    // 类型名称（仅调试用）
    uint32_t    blink_interval;          // 闪烁间隔（ms），0表示常亮
    uint8_t     is_breathing;            // 是否为呼吸灯模式
    void (*update)(led_flyweight_t *fw, uint8_t *state, uint32_t current_tick);
};

// 4种共享的享元对象（静态定义，只有一份）
extern led_flyweight_t led_type_constant;   // 常亮
extern led_flyweight_t led_type_slow_blink; // 慢闪
extern led_flyweight_t led_type_fast_blink; // 快闪
extern led_flyweight_t led_type_breathing;  // 呼吸灯

void led_flyweight_init_all(void);

#endif