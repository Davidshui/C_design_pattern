// led_context.h
#ifndef LED_CONTEXT_H
#define LED_CONTEXT_H

#include "flyweight.h"

typedef struct led_context led_context_t;

// 每个LED的外部状态（轻量级）
struct led_context {
    led_flyweight_t *flyweight;     // 指向共享的享元对象（关键！）
    GPIO_TypeDef    *gpio_port;
    uint16_t         gpio_pin;
    uint8_t          current_state; // 当前实际输出状态（0/1或亮度）
};

void led_context_init(led_context_t *led,
                      led_flyweight_t *type,
                      GPIO_TypeDef *port,
                      uint16_t pin);

void led_context_update(led_context_t *led, uint32_t current_tick);

#endif