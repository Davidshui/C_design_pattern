// led_flyweight.c
#include "flyweight.h"
#include "stm32f4xx_hal.h"   // 用于HAL_GetTick，实际项目替换为你的tick函数

static void constant_update(led_flyweight_t *fw, uint8_t *state, uint32_t current_tick)
{
    *state = 1;        // 永远点亮
}

static void slow_blink_update(led_flyweight_t *fw, uint8_t *state, uint32_t current_tick)
{
    *state = ((current_tick / fw->blink_interval) % 2) == 0 ? 1 : 0;
}

static void fast_blink_update(led_flyweight_t *fw, uint8_t *state, uint32_t current_tick)
{
    *state = ((current_tick / fw->blink_interval) % 2) == 0 ? 1 : 0;
}

static void breathing_update(led_flyweight_t *fw, uint8_t *state, uint32_t current_tick)
{
    // 简单模拟呼吸效果（实际可用PWM实现）
    uint32_t t = (current_tick % 2000);
    *state = (t < 1000) ? (t / 10) : (200 - t / 10);
}

// 定义4个共享的享元对象（只存在一份）
led_flyweight_t led_type_constant = {
    .name = "constant",
    .blink_interval = 0,
    .is_breathing = 0,
    .update = constant_update
};

led_flyweight_t led_type_slow_blink = {
    .name = "slow_blink",
    .blink_interval = 800,
    .is_breathing = 0,
    .update = slow_blink_update
};

led_flyweight_t led_type_fast_blink = {
    .name = "fast_blink",
    .blink_interval = 150,
    .is_breathing = 0,
    .update = fast_blink_update
};

led_flyweight_t led_type_breathing = {
    .name = "breathing",
    .blink_interval = 0,
    .is_breathing = 1,
    .update = breathing_update
};

void led_flyweight_init_all(void)
{
    // 这里可以做一些初始化工作，目前为空
}