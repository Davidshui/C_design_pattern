// led_context.c
#include "led_context.h"

void led_context_init(led_context_t *led,
                      led_flyweight_t *type,
                      GPIO_TypeDef *port,
                      uint16_t pin)
{
    if (led == NULL) return;
    
    led->flyweight     = type;
    led->gpio_port     = port;
    led->gpio_pin      = pin;
    led->current_state = 0;
}

void led_context_update(led_context_t *led, uint32_t current_tick)
{
    if (led == NULL || led->flyweight == NULL) return;

    uint8_t new_state = 0;
    led->flyweight->update(led->flyweight, &new_state, current_tick);

    // 只在状态变化时才操作硬件，减少翻转
    if (new_state != led->current_state) {
        led->current_state = new_state;
        if (new_state)
            HAL_GPIO_WritePin(led->gpio_port, led->gpio_pin, GPIO_PIN_SET);
        else
            HAL_GPIO_WritePin(led->gpio_port, led->gpio_pin, GPIO_PIN_RESET);
    }
}