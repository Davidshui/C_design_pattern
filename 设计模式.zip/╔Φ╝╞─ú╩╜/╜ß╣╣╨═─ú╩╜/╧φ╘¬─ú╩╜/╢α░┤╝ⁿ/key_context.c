// key_context.c
#include "key_context.h"

void key_context_init(key_context_t *key,
                      const key_flyweight_t *type,
                      GPIO_TypeDef *port,
                      uint16_t pin)
{
    if (key == NULL) return;
    
    key->flyweight         = type;
    key->gpio_port         = port;
    key->gpio_pin          = pin;
    key->current_level     = 1;        // 假设按键默认高电平（未按下）
    key->last_level        = 1;
    key->last_change_tick  = 0;
    key->press_start_tick  = 0;
}

void key_context_update(key_context_t *key, uint32_t current_tick)
{
    if (key == NULL || key->flyweight == NULL) return;

    uint8_t raw_level = HAL_GPIO_ReadPin(key->gpio_port, key->gpio_pin);  // 实际读取GPIO

    // 简单消抖逻辑（使用共享的debounce_time_ms）
    if (raw_level != key->last_level) {
        if (current_tick - key->last_change_tick >= key->flyweight->debounce_time_ms) {
            key->last_level = raw_level;
            key->last_change_tick = current_tick;
            
            if (raw_level == 0) {  // 按下
                key->press_start_tick = current_tick;
            }
        }
    }

    key->current_level = key->last_level;

    // 调用共享的行为处理（可扩展为事件触发）
    if (key->flyweight->process) {
        key->flyweight->process((key_flyweight_t *)key->flyweight, &key->current_level, current_tick);
    }
}