// key_context.h
#ifndef KEY_CONTEXT_H
#define KEY_CONTEXT_H

#include "key_flyweight.h"

typedef struct key_context key_context_t;

// 每个按键独有的外部状态（轻量）
struct key_context {
    const key_flyweight_t *flyweight;   // 指向共享享元对象（关键！）
    
    GPIO_TypeDef *gpio_port;            // 外部状态：硬件引脚
    uint16_t      gpio_pin;
    
    uint8_t       current_level;        // 当前电平（0/1）
    uint8_t       last_level;
    uint32_t      last_change_tick;     // 上次状态变化时间
    uint32_t      press_start_tick;     // 按下开始时间
};

void key_context_init(key_context_t *key,
                      const key_flyweight_t *type,
                      GPIO_TypeDef *port,
                      uint16_t pin);

void key_context_update(key_context_t *key, uint32_t current_tick);

#endif