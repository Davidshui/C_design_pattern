/**
本次场景：大量按键（Key）对象管理（非常常见的嵌入式应用）
系统中可能有 50~200 个按键（矩阵键盘、触摸按键、面板按键等），但按键类型通常只有少数几种：短按、长按、双击、连续触发 等。
每种类型有共同的行为逻辑（内部状态：按键处理函数、消抖时间、长按阈值等），但每个按键有自己的外部状态（GPIO引脚、当前状态、计数器等）。
享元模式让相同类型的按键共享同一份行为逻辑，大幅节省RAM。
*/
// main.c
#include "key_flyweight.h"
#include "key_context.h"

// 静态分配所有按键上下文（外部状态）
#define MAX_KEYS 100
static key_context_t keys[MAX_KEYS];

int main(void)
{
    // 初始化100个按键，只需指定不同引脚和共享的类型
    key_context_init(&keys[0],  &key_type_short_press,  GPIOA, GPIO_PIN_0);
    key_context_init(&keys[1],  &key_type_long_press,   GPIOA, GPIO_PIN_1);
    key_context_init(&keys[2],  &key_type_double_click, GPIOA, GPIO_PIN_2);
    key_context_init(&keys[3],  &key_type_repeat,       GPIOA, GPIO_PIN_3);

    // 其余按键使用常见类型
    for (int i = 4; i < MAX_KEYS; i++) {
        key_context_init(&keys[i], &key_type_short_press, GPIOB, i % 16);
    }

    uint32_t tick = 0;
    while (1) {
        tick = HAL_GetTick();

        // 统一更新所有按键（享元共享行为逻辑）
        for (int i = 0; i < MAX_KEYS; i++) {
            key_context_update(&keys[i], tick);
        }

        // 这里可根据 key->current_level 处理具体事件
        HAL_Delay(10);
    }
}