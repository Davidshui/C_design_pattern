// key_flyweight.h
#ifndef KEY_FLYWEIGHT_H
#define KEY_FLYWEIGHT_H

#include <stdint.h>

// 共享的内部状态（享元对象）
typedef struct key_flyweight key_flyweight_t;

struct key_flyweight {
    const char *type_name;           // 类型名称（调试用）
    uint16_t    debounce_time_ms;    // 消抖时间
    uint16_t    long_press_time_ms;  // 长按阈值
    uint16_t    repeat_interval_ms;  // 连发间隔（0表示不连发）

    // 共享的行为函数
    void (*process)(key_flyweight_t *fw, uint8_t *key_state, uint32_t current_tick);
};

#endif
