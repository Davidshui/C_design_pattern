// key_flyweight.c
#include "key_flyweight.h"
#include "stm32f4xx_hal.h"   // 实际项目替换为你的tick获取函数

// 4种共享的享元对象（全局只存在一份，使用const）
const key_flyweight_t key_type_short_press = {
    .type_name          = "short_press",
    .debounce_time_ms   = 20,
    .long_press_time_ms = 0,
    .repeat_interval_ms = 0,
    .process            = NULL   // 后面在init中赋值或直接用外部处理
};

const key_flyweight_t key_type_long_press = {
    .type_name          = "long_press",
    .debounce_time_ms   = 30,
    .long_press_time_ms = 800,
    .repeat_interval_ms = 0,
    .process            = NULL
};

const key_flyweight_t key_type_double_click = {
    .type_name          = "double_click",
    .debounce_time_ms   = 20,
    .long_press_time_ms = 0,
    .repeat_interval_ms = 0,
    .process            = NULL
};

const key_flyweight_t key_type_repeat = {
    .type_name          = "repeat",
    .debounce_time_ms   = 25,
    .long_press_time_ms = 600,
    .repeat_interval_ms = 150,
    .process            = NULL
};

// 简单共享处理函数示例（实际可根据需要扩展）
void key_common_process(key_flyweight_t *fw, uint8_t *key_state, uint32_t current_tick)
{
    // 这里可放入通用消抖、长按判断等逻辑
    (void)fw;
    (void)key_state;
    (void)current_tick;
    // 实际项目中可调用事件回调
}