/* winbond_adapter.c */
#include "flash_adapter.h"
#include <stdio.h>

/* Winbond 私有数据 */
typedef struct {
    uint8_t  spi_cs_pin;
    uint32_t capacity;      // 例如 8MB = 8*1024*1024
} winbond_priv_t;

/* 底层驱动模拟函数（实际项目中替换为真实 SPI + W25Q 命令） */
static bool winbond_real_init(winbond_priv_t *priv)
{
    printf("[Winbond] W25Q Flash 初始化完成 (CS=%d, Capacity=%u bytes)\n", 
           priv->spi_cs_pin, priv->capacity);
    return true;
}

static bool winbond_real_read(winbond_priv_t *priv, uint32_t addr, uint8_t *buf, uint32_t len)
{
    (void)priv;
    printf("[Winbond] 读取地址 0x%08X, 长度 %u\n", addr, len);
    /* 实际应发送 0x03 Read 命令 */
    return true;
}

static bool winbond_real_write(winbond_priv_t *priv, uint32_t addr, const uint8_t *data, uint32_t len)
{
    (void)priv; (void)data;
    printf("[Winbond] 写入地址 0x%08X, 长度 %u\n", addr, len);
    return true;
}

static bool winbond_real_erase_sector(winbond_priv_t *priv, uint32_t addr)
{
    (void)priv;
    printf("[Winbond] 擦除扇区 0x%08X\n", addr);
    return true;
}

/* ====================== 适配器函数 ====================== */
static bool winbond_adapter_init(flash_device_t *dev)
{
    winbond_priv_t *priv = (winbond_priv_t *)dev->priv;
    return winbond_real_init(priv);
}

static bool winbond_adapter_read(flash_device_t *dev, uint32_t addr, uint8_t *buf, uint32_t len)
{
    return winbond_real_read((winbond_priv_t*)dev->priv, addr, buf, len);
}

static bool winbond_adapter_write(flash_device_t *dev, uint32_t addr, const uint8_t *data, uint32_t len)
{
    return winbond_adapter_write((winbond_priv_t*)dev->priv, addr, data, len);
}

static bool winbond_adapter_erase_sector(flash_device_t *dev, uint32_t addr)
{
    return winbond_real_erase_sector((winbond_priv_t*)dev->priv, addr);
}

static bool winbond_adapter_erase_chip(flash_device_t *dev)
{
    (void)dev;
    printf("[Winbond] 执行整片擦除\n");
    return true;
}

static uint32_t winbond_get_capacity(flash_device_t *dev)
{
    winbond_priv_t *priv = (winbond_priv_t *)dev->priv;
    return priv->capacity;
}

/* 创建 Winbond 适配器 */
void flash_create_winbond_adapter(flash_device_t *dev, uint8_t cs_pin, uint32_t capacity)
{
    static winbond_priv_t priv;
    static const flash_ops_t ops = {
        .init           = winbond_adapter_init,
        .read           = winbond_adapter_read,
        .write          = winbond_adapter_write,
        .erase_sector   = winbond_adapter_erase_sector,
        .erase_chip     = winbond_adapter_erase_chip,
        .get_capacity   = winbond_get_capacity,
        .name           = "Winbond W25Q"
    };

    priv.spi_cs_pin = cs_pin;
    priv.capacity = capacity;

    dev->ops = &ops;
    dev->priv = &priv;
}