/* internal_flash_adapter.c */
#include "flash_adapter.h"
#include <stdio.h>

typedef struct {
    uint32_t base_addr;
    uint32_t size;
} internal_flash_priv_t;

static bool internal_flash_init(flash_device_t *dev)
{
    internal_flash_priv_t *priv = (internal_flash_priv_t *)dev->priv;
    printf("[Internal Flash] MCU内置Flash初始化完成 (0x%08X, %u KB)\n", 
           priv->base_addr, priv->size/1024);
    return true;
}

static bool internal_flash_read(flash_device_t *dev, uint32_t addr, uint8_t *buf, uint32_t len)
{
    (void)dev; (void)buf;
    printf("[Internal Flash] 读取地址 0x%08X, 长度 %u\n", addr, len);
    return true;
}

static uint32_t internal_get_capacity(flash_device_t *dev)
{
    internal_flash_priv_t *priv = (internal_flash_priv_t *)dev->priv;
    return priv->size;
}

/* 创建内部 Flash 适配器 */
void flash_create_internal_adapter(flash_device_t *dev, uint32_t base_addr, uint32_t size)
{
    static internal_flash_priv_t priv;
    static const flash_ops_t ops = {
        .init           = internal_flash_init,
        .read           = internal_flash_read,
        .write          = NULL,   // 实际需实现
        .erase_sector   = NULL,
        .erase_chip     = NULL,
        .get_capacity   = internal_get_capacity,
        .name           = "Internal MCU Flash"
    };

    priv.base_addr = base_addr;
    priv.size = size;

    dev->ops = &ops;
    dev->priv = &priv;
}