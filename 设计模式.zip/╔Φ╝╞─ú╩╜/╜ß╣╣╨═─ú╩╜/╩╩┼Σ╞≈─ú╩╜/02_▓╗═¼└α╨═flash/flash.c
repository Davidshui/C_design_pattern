/* flash.c */
#include "flash.h"
#include <stdio.h>

bool flash_init(flash_device_t *dev)
{
    if (!dev || !dev->ops || !dev->ops->init) return false;
    return dev->ops->init(dev);
}

bool flash_read(flash_device_t *dev, uint32_t addr, uint8_t *buf, uint32_t len)
{
    if (!dev || !dev->ops || !dev->ops->read) return false;
    return dev->ops->read(dev, addr, buf, len);
}

bool flash_write(flash_device_t *dev, uint32_t addr, const uint8_t *data, uint32_t len)
{
    if (!dev || !dev->ops || !dev->ops->write) return false;
    return dev->ops->write(dev, addr, data, len);
}

bool flash_erase_sector(flash_device_t *dev, uint32_t addr)
{
    if (!dev || !dev->ops || !dev->ops->erase_sector) return false;
    return dev->ops->erase_sector(dev, addr);
}

bool flash_erase_chip(flash_device_t *dev)
{
    if (!dev || !dev->ops || !dev->ops->erase_chip) return false;
    return dev->ops->erase_chip(dev);
}

uint32_t flash_get_capacity(flash_device_t *dev)
{
    if (!dev || !dev->ops || !dev->ops->get_capacity) return 0;
    return dev->ops->get_capacity(dev);
}

uint32_t flash_get_sector_size(flash_device_t *dev)
{
    if (!dev || !dev->ops || !dev->ops->get_sector_size) return 4096; // 默认4KB
    return dev->ops->get_sector_size(dev);
}

uint32_t flash_get_page_size(flash_device_t *dev)
{
    if (!dev || !dev->ops || !dev->ops->get_page_size) return 256;   // 默认256B
    return dev->ops->get_page_size(dev);
}
