/* flash_adapter.h */
#ifndef FLASH_ADAPTER_H
#define FLASH_ADAPTER_H

#include <stdint.h>
#include <stdbool.h>

/* ==================== 统一 Flash 接口（Target） ==================== */
typedef struct flash_device flash_device_t;

typedef struct {
    /* 基础操作 */
    bool     (*init)(flash_device_t *dev);
    bool     (*read)(flash_device_t *dev, uint32_t addr, uint8_t *buf, uint32_t len);
    bool     (*write)(flash_device_t *dev, uint32_t addr, const uint8_t *data, uint32_t len);
    bool     (*erase_sector)(flash_device_t *dev, uint32_t addr);   // 4KB sector
    bool     (*erase_chip)(flash_device_t *dev);

    /* 信息查询 */
    uint32_t (*get_capacity)(flash_device_t *dev);   // 返回字节数
    uint16_t (*get_page_size)(flash_device_t *dev);
    uint32_t (*get_sector_size)(flash_device_t *dev);
    
    const char* name;
} flash_ops_t;

struct flash_device {
    const flash_ops_t *ops;
    void *priv;                    // 指向具体厂商的驱动数据
};

/* ==================== 接口函数 ==================== */
bool flash_init(flash_device_t *dev);
bool flash_read(flash_device_t *dev, uint32_t addr, uint8_t *buf, uint32_t len);
bool flash_write(flash_device_t *dev, uint32_t addr, const uint8_t *data, uint32_t len);
bool flash_erase_sector(flash_device_t *dev, uint32_t addr);
bool flash_erase_chip(flash_device_t *dev);

uint32_t flash_get_capacity(flash_device_t *dev);
uint32_t flash_get_sector_size(flash_device_t *dev);
uint32_t flash_get_page_size(flash_device_t *dev);

#endif