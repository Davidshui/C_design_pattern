/* sensors.c */
#include "temperature_sensor.h"
#include <stdio.h>

void sensor_a_init(sensor_a_t *dev)
{
    printf("[Sensor A] I2C 地址 0x%02X 初始化\n", dev->i2c_addr);
    dev->raw_value = 256;   // 25.6°C
}

int16_t sensor_a_read_raw(sensor_a_t *dev)
{
    return dev->raw_value;
}

uint8_t sensor_a_get_status(sensor_a_t *dev)
{
    (void)dev;
    return 0;
}

void sensor_b_init(sensor_b_t *dev)
{
    printf("[Sensor B] SPI CS引脚 %d 初始化\n", dev->spi_cs_pin);
    dev->calibrated_value = 28.5f;
}

float sensor_b_read_temperature(sensor_b_t *dev)
{
    return dev->calibrated_value;
}

void sensor_c_init(sensor_c_t *dev)
{
    printf("[Sensor C] ADC 通道 %d 初始化\n", dev->adc_channel);
}

uint16_t sensor_c_read_adc(sensor_c_t *dev)
{
    (void)dev;
    return 4500;   // 对应约 25°C
}