/* adapters.c */
#include "temperature_sensor.h"
#include <stdio.h>

/* ====================== Sensor A 适配器 ====================== */
static void sensor_a_adapter_init(void *adapter)
{
    sensor_a_t *dev = (sensor_a_t *)adapter;
    sensor_a_init(dev);
    printf("[Adapter A] I2C 传感器初始化完成\n");
}

static float sensor_a_adapter_get_temp(void *adapter)
{
    sensor_a_t *dev = (sensor_a_t *)adapter;
    int16_t raw = sensor_a_read_raw(dev);
    // 假设转换公式：温度 = raw / 10.0
    return raw / 10.0f;
}

static uint8_t sensor_a_adapter_get_status(void *adapter)
{
    sensor_a_t *dev = (sensor_a_t *)adapter;
    return sensor_a_get_status(dev);
}

/* 创建 Sensor A 的适配器 */
void create_sensor_a_adapter(temperature_sensor_t *sensor, sensor_a_t *dev)
{
    sensor->init = sensor_a_adapter_init;
    sensor->get_temperature = sensor_a_adapter_get_temp;
    sensor->get_status = sensor_a_adapter_get_status;
    sensor->name = "Sensor_A (I2C)";
    sensor->init(dev);   // 初始化底层设备
}

/* ====================== Sensor B 适配器 ====================== */
static void sensor_b_adapter_init(void *adapter)
{
    sensor_b_t *dev = (sensor_b_t *)adapter;
    sensor_b_init(dev);
    printf("[Adapter B] SPI 传感器初始化完成\n");
}

static float sensor_b_adapter_get_temp(void *adapter)
{
    sensor_b_t *dev = (sensor_b_t *)adapter;
    return sensor_b_read_temperature(dev);
}

static uint8_t sensor_b_adapter_get_status(void *adapter)
{
    (void)adapter;
    return 0;   // 假设总是正常
}

void create_sensor_b_adapter(temperature_sensor_t *sensor, sensor_b_t *dev)
{
    sensor->init = sensor_b_adapter_init;
    sensor->get_temperature = sensor_b_adapter_get_temp;
    sensor->get_status = sensor_b_adapter_get_status;
    sensor->name = "Sensor_B (SPI)";
    sensor->init(dev);
}

/* ====================== Sensor C 适配器 ====================== */
static void sensor_c_adapter_init(void *adapter)
{
    sensor_c_t *dev = (sensor_c_t *)adapter;
    sensor_c_init(dev);
    printf("[Adapter C] ADC 传感器初始化完成\n");
}

static float sensor_c_adapter_get_temp(void *adapter)
{
    sensor_c_t *dev = (sensor_c_t *)adapter;
    uint16_t adc = sensor_c_read_adc(dev);
    // 假设转换公式：温度 = (adc * 0.01) - 20.0
    return (adc * 0.01f) - 20.0f;
}

static uint8_t sensor_c_adapter_get_status(void *adapter)
{
    (void)adapter;
    return 0;
}

void create_sensor_c_adapter(temperature_sensor_t *sensor, sensor_c_t *dev)
{
    sensor->init = sensor_c_adapter_init;
    sensor->get_temperature = sensor_c_adapter_get_temp;
    sensor->get_status = sensor_c_adapter_get_status;
    sensor->name = "Sensor_C (ADC)";
    sensor->init(dev);
}