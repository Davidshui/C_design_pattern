/* temperature_sensor.h */
#ifndef TEMPERATURE_SENSOR_ADAPTER_H
#define TEMPERATURE_SENSOR_ADAPTER_H

#include <stdint.h>
#include <stdbool.h>

/* 统一传感器接口（Target）—— 上层希望使用的接口 */
typedef struct {
    void (*init)(void *adapter);
    float (*get_temperature)(void *adapter);   // 返回温度（单位：°C）
    uint8_t (*get_status)(void *adapter);      // 0=正常, 1=警告, 2=故障
    const char *name;
} temperature_sensor_t;

/* ==================== 具体传感器驱动接口（Adaptee） ==================== */

/* Sensor A - I2C 传感器（旧接口） */
typedef struct {
    uint8_t i2c_addr;
    int16_t raw_value;
} sensor_a_t;

void sensor_a_init(sensor_a_t *dev);
int16_t sensor_a_read_raw(sensor_a_t *dev);
uint8_t sensor_a_get_status(sensor_a_t *dev);

/* Sensor B - SPI 传感器（新接口） */
typedef struct {
    uint8_t spi_cs_pin;
    float   calibrated_value;
} sensor_b_t;

void sensor_b_init(sensor_b_t *dev);
float sensor_b_read_temperature(sensor_b_t *dev);

/* Sensor C - ADC 传感器（模拟接口） */
typedef struct {
    uint8_t adc_channel;
} sensor_c_t;

void sensor_c_init(sensor_c_t *dev);
uint16_t sensor_c_read_adc(sensor_c_t *dev);

#endif