/* main.c */
/**
上层业务代码只需使用 temperature_sensor_t 统一接口，无需关心底层是 I2C、SPI 还是 ADC。
新增传感器时，只需写一个新的适配器即可
*/
#include "temperature_sensor.h"
#include <stdio.h>

int main(void)
{
    temperature_sensor_t sensor;
    sensor_a_t sensor_a_dev = {.i2c_addr = 0x48};
    sensor_b_t sensor_b_dev = {.spi_cs_pin = 5};
    sensor_c_t sensor_c_dev = {.adc_channel = 3};

    printf("=== 嵌入式适配器模式演示 - 统一温度传感器接口 ===\n\n");

    /* 使用 Sensor A */
    create_sensor_a_adapter(&sensor, &sensor_a_dev);
    printf("温度: %.2f °C  状态: %d\n", 
           sensor.get_temperature(&sensor_a_dev), sensor.get_status(&sensor_a_dev));

    /* 切换到 Sensor B */
    create_sensor_b_adapter(&sensor, &sensor_b_dev);
    printf("温度: %.2f °C  状态: %d\n", 
           sensor.get_temperature(&sensor_b_dev), sensor.get_status(&sensor_b_dev));

    /* 切换到 Sensor C */
    create_sensor_c_adapter(&sensor, &sensor_c_dev);
    printf("温度: %.2f °C  状态: %d\n", 
           sensor.get_temperature(&sensor_c_dev), sensor.get_status(&sensor_c_dev));

    return 0;
}