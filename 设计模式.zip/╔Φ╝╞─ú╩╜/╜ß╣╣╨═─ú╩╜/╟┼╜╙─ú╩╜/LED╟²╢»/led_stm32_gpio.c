// led_stm32_gpio.c
#include "led_impl.h"
#include "stm32f4xx_hal.h"

typedef struct {
    led_impl_t base;
    GPIO_TypeDef *gpio_port;
    uint16_t gpio_pin;
} led_stm32_gpio_t;

static void stm32_gpio_init(led_impl_t *impl)
{
    /* GPIO已在CubeMX或上层初始化，此处可留空或做额外配置 */
}

static void stm32_gpio_on(led_impl_t *impl)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)impl;
    HAL_GPIO_WritePin(self->gpio_port, self->gpio_pin, GPIO_PIN_SET);
}

static void stm32_gpio_off(led_impl_t *impl)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)impl;
    HAL_GPIO_WritePin(self->gpio_port, self->gpio_pin, GPIO_PIN_RESET);
}

static void stm32_gpio_toggle(led_impl_t *impl)
{
    led_stm32_gpio_t *self = (led_stm32_gpio_t *)impl;
    HAL_GPIO_TogglePin(self->gpio_port, self->gpio_pin);
}

static void stm32_gpio_set_brightness(led_impl_t *impl, uint8_t brightness)
{
    (void)brightness;   /* GPIO不支持PWM，忽略 */
}

void led_stm32_gpio_init(led_stm32_gpio_t *obj,
                         GPIO_TypeDef *gpio_port,
                         uint16_t gpio_pin)
{
    if (obj == NULL) return;

    obj->base.init           = stm32_gpio_init;
    obj->base.on             = stm32_gpio_on;
    obj->base.off            = stm32_gpio_off;
    obj->base.toggle         = stm32_gpio_toggle;
    obj->base.set_brightness = stm32_gpio_set_brightness;

    obj->gpio_port = gpio_port;
    obj->gpio_pin  = gpio_pin;
}