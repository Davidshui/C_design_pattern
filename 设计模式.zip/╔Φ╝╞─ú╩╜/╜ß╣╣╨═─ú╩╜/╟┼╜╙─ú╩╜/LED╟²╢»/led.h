// led.h
#ifndef LED_H
#define LED_H

#include "led_impl.h"

typedef struct led led_t;

struct led {
    led_impl_t *impl;     /* 桥接核心指针 */

    void (*init)(led_t *led);
    void (*on)(led_t *led);
    void (*off)(led_t *led);
    void (*toggle)(led_t *led);
    void (*set_brightness)(led_t *led, uint8_t brightness);
};

void led_init(led_t *led, led_impl_t *impl);
void led_destroy(led_t *led);   /* 如果需要做清理，这里可留空 */

#endif