// main.c

/*
业务层 (main.c)
   │
   ▼
抽象层 (led_t)  ← 对外接口，完全不变
   │
   └─► 桥接指针 (impl)
         │
         ├─► led_stm32_gpio_t     (直接GPIO实现)
         └─► led_i2c_device_t     (新增的I2C设备实现)
               │
               └─► 调用i2c_write_register(...)

*/
#include "led.h"
#include "led_stm32_gpio.h"
#include "led_i2c_device.h"

// 调用者提供所有内存（静态分配）
static led_t                status_led;      // 抽象LED
static led_stm32_gpio_t     gpio_led_impl;   // GPIO实现
static led_i2c_device_t     i2c_led_impl;    // I2C实现

int main(void)
{
    // ==================== GPIO方式的LED ====================
    led_stm32_gpio_init(&gpio_led_impl, GPIOA, GPIO_PIN_5);
    led_init(&status_led, &gpio_led_impl.base);

    status_led.init(&status_led);

    // 使用GPIO控制LED闪烁
    while (1) {
        status_led.on(&status_led);
        delay_ms(300);
        status_led.off(&status_led);
        delay_ms(300);
    }

    // ==================== 如果想切换为I2C方式，只需下面几行 ====================
    /*
    led_i2c_device_init(&i2c_led_impl, 0x18, 0x01);   // I2C地址0x18，第0位LED
    led_init(&status_led, &i2c_led_impl.base);         // 重新桥接
    
    status_led.init(&status_led);
    
    while (1) {
        status_led.on(&status_led);
        delay_ms(500);
        status_led.off(&status_led);
        delay_ms(500);
    }
    */
}