// led_i2c_device.c
#include "led_impl.h"

// 假设你已经有I2C驱动，这里使用简化的i2c_write_register函数
// 实际项目中请替换为你的I2C HAL函数
extern void i2c_write_register(uint8_t dev_addr, uint8_t reg, uint8_t data);

typedef struct {
    led_impl_t base;
    uint8_t    i2c_addr;      // I2C从机地址
    uint8_t    pin_mask;      // 该LED对应的位掩码（如 0x01 表示第0位）
    uint8_t    current_state; // 缓存当前状态，减少I2C通信
} led_i2c_device_t;

static void i2c_device_init(led_impl_t *impl)
{
    led_i2c_device_t *self = (led_i2c_device_t *)impl;
    self->current_state = 0;   // 初始关闭
    
    // 可在此处初始化I2C扩展芯片的寄存器（如方向寄存器设为输出）
    // i2c_write_register(self->i2c_addr, 0x03, 0x00); // 示例：配置为输出
}

static void i2c_device_on(led_impl_t *impl)
{
    led_i2c_device_t *self = (led_i2c_device_t *)impl;
    self->current_state |= self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);  // 输出寄存器
}

static void i2c_device_off(led_impl_t *impl)
{
    led_i2c_device_t *self = (led_i2c_device_t *)impl;
    self->current_state &= ~self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);
}

static void i2c_device_toggle(led_impl_t *impl)
{
    led_i2c_device_t *self = (led_i2c_device_t *)impl;
    self->current_state ^= self->pin_mask;
    i2c_write_register(self->i2c_addr, 0x01, self->current_state);
}

static void i2c_device_set_brightness(led_impl_t *impl, uint8_t brightness)
{
    (void)impl;
    (void)brightness;
    // I2C扩展芯片通常不支持PWM，可忽略或用软件模拟
}

void led_i2c_device_init(led_i2c_device_t *obj,
                         uint8_t i2c_addr,
                         uint8_t pin_mask)
{
    if (obj == NULL) return;

    obj->base.init           = i2c_device_init;
    obj->base.on             = i2c_device_on;
    obj->base.off            = i2c_device_off;
    obj->base.toggle         = i2c_device_toggle;
    obj->base.set_brightness = i2c_device_set_brightness;

    obj->i2c_addr      = i2c_addr;
    obj->pin_mask      = pin_mask;
    obj->current_state = 0;
}