// led_impl.h
#ifndef LED_IMPL_H
#define LED_IMPL_H

typedef struct led_impl led_impl_t;

struct led_impl {
    void (*init)(led_impl_t *impl);
    void (*on)(led_impl_t *impl);
    void (*off)(led_impl_t *impl);
    void (*toggle)(led_impl_t *impl);
    void (*set_brightness)(led_impl_t *impl, uint8_t brightness);  /* 0~100 */
};

#endif