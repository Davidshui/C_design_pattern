// led.c
#include "led.h"

static void led_init_func(led_t *led)
{
    if (led && led->impl && led->impl->init)
        led->impl->init(led->impl);
}

static void led_on_func(led_t *led)
{
    if (led && led->impl && led->impl->on)
        led->impl->on(led->impl);
}

static void led_off_func(led_t *led)
{
    if (led && led->impl && led->impl->off)
        led->impl->off(led->impl);
}

static void led_toggle_func(led_t *led)
{
    if (led && led->impl && led->impl->toggle)
        led->impl->toggle(led->impl);
}

static void led_set_brightness_func(led_t *led, uint8_t brightness)
{
    if (led && led->impl && led->impl->set_brightness)
        led->impl->set_brightness(led->impl, brightness);
}

void led_init(led_t *led, led_impl_t *impl)
{
    if (led == NULL) return;

    led->impl            = impl;
    led->init            = led_init_func;
    led->on              = led_on_func;
    led->off             = led_off_func;
    led->toggle          = led_toggle_func;
    led->set_brightness  = led_set_brightness_func;
}