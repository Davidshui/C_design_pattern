// gpio_direction_subsystem.c
#include "gpio_direction_subsystem.h"
#include <stdio.h>

static void dir_init(gpio_direction_subsystem_t *dir)
{
    printf("方向GPIO子系统初始化完成\n");
}

static void dir_set_forward(gpio_direction_subsystem_t *dir)
{
    printf("电机方向设置为：正转\n");
}

static void dir_set_reverse(gpio_direction_subsystem_t *dir)
{
    printf("电机方向设置为：反转\n");
}

void gpio_direction_subsystem_init(gpio_direction_subsystem_t *dir)
{
    if (dir == NULL) return;
    dir->init = dir_init;
    dir->set_forward = dir_set_forward;
    dir->set_reverse = dir_set_reverse;
    dir->init(dir);
}