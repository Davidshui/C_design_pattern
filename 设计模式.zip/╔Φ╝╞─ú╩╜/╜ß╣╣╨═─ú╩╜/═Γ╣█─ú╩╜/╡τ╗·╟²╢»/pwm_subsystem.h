// pwm_subsystem.h
#ifndef PWM_SUBSYSTEM_H
#define PWM_SUBSYSTEM_H

typedef struct pwm_subsystem pwm_subsystem_t;

struct pwm_subsystem {
    void (*init)(pwm_subsystem_t *pwm);
    void (*set_duty)(pwm_subsystem_t *pwm, uint16_t duty);   // 0~1000 (0.0% ~ 100.0%)
    void (*start)(pwm_subsystem_t *pwm);
    void (*stop)(pwm_subsystem_t *pwm);
};

void pwm_subsystem_init(pwm_subsystem_t *pwm);

#endif