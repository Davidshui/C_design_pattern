// motor_control_facade.c
#include "motor_control_facade.h"
#include <stdio.h>

static void facade_init(motor_control_facade_t *facade)
{
    if (facade->pwm)         facade->pwm->init(facade->pwm);
    if (facade->direction)   facade->direction->init(facade->direction);
    if (facade->current_mon) facade->current_mon->init(facade->current_mon);
    
    printf("=== 电机控制外观初始化完成 ===\n");
}

static void facade_start_forward(motor_control_facade_t *facade, uint16_t speed)
{
    if (facade->current_mon && facade->current_mon->is_overcurrent(facade->current_mon)) {
        printf("过流保护！无法启动电机\n");
        return;
    }

    if (facade->direction)   facade->direction->set_forward(facade->direction);
    if (facade->pwm) {
        facade->pwm->set_duty(facade->pwm, speed);
        facade->pwm->start(facade->pwm);
    }
    
    printf("电机正转启动，速度 %u\n", speed);
}

static void facade_start_reverse(motor_control_facade_t *facade, uint16_t speed)
{
    if (facade->current_mon && facade->current_mon->is_overcurrent(facade->current_mon)) {
        printf("过流保护！无法启动电机\n");
        return;
    }

    if (facade->direction)   facade->direction->set_reverse(facade->direction);
    if (facade->pwm) {
        facade->pwm->set_duty(facade->pwm, speed);
        facade->pwm->start(facade->pwm);
    }
    
    printf("电机反转启动，速度 %u\n", speed);
}

static void facade_stop(motor_control_facade_t *facade)
{
    if (facade->pwm) facade->pwm->stop(facade->pwm);
    printf("电机停止\n");
}

static void facade_emergency_stop(motor_control_facade_t *facade)
{
    if (facade->pwm) facade->pwm->stop(facade->pwm);
    printf("紧急停止！电机已立即切断\n");
    // 可在这里加入硬件刹车或继电器断电等强保护动作
}

static void facade_update_status(motor_control_facade_t *facade)
{
    if (facade->current_mon && facade->current_mon->is_overcurrent(facade->current_mon)) {
        facade_emergency_stop(facade);
    }
}

void motor_control_facade_init(motor_control_facade_t *facade,
                               pwm_subsystem_t *pwm,
                               gpio_direction_subsystem_t *direction,
                               current_monitor_subsystem_t *current_mon)
{
    if (facade == NULL) return;

    facade->pwm         = pwm;
    facade->direction   = direction;
    facade->current_mon = current_mon;

    facade->init             = facade_init;
    facade->start_forward    = facade_start_forward;
    facade->start_reverse    = facade_start_reverse;
    facade->stop             = facade_stop;
    facade->emergency_stop   = facade_emergency_stop;
    facade->update_status    = facade_update_status;

    facade->init(facade);
}