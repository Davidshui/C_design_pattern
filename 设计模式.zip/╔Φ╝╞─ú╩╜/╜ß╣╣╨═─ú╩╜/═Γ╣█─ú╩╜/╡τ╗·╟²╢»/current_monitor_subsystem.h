// current_monitor_subsystem.h
#ifndef CURRENT_MONITOR_SUBSYSTEM_H
#define CURRENT_MONITOR_SUBSYSTEM_H

typedef struct current_monitor_subsystem current_monitor_subsystem_t;

struct current_monitor_subsystem {
    void (*init)(current_monitor_subsystem_t *mon);
    uint16_t (*get_current_ma)(current_monitor_subsystem_t *mon);  // 返回毫安
    uint8_t (*is_overcurrent)(current_monitor_subsystem_t *mon);
};

void current_monitor_subsystem_init(current_monitor_subsystem_t *mon);

#endif