// motor_control_facade.h
#ifndef MOTOR_CONTROL_FACADE_H
#define MOTOR_CONTROL_FACADE_H

#include <stdint.h>
#include "pwm_subsystem.h"
#include "gpio_direction_subsystem.h"
#include "current_monitor_subsystem.h"

typedef struct motor_control_facade motor_control_facade_t;

struct motor_control_facade {
    pwm_subsystem_t               *pwm;
    gpio_direction_subsystem_t    *direction;
    current_monitor_subsystem_t   *current_mon;

    void (*init)(motor_control_facade_t *facade);
    void (*start_forward)(motor_control_facade_t *facade, uint16_t speed);   // speed: 0~1000
    void (*start_reverse)(motor_control_facade_t *facade, uint16_t speed);
    void (*stop)(motor_control_facade_t *facade);
    void (*emergency_stop)(motor_control_facade_t *facade);
    void (*update_status)(motor_control_facade_t *facade);                   // 主循环调用
};

void motor_control_facade_init(motor_control_facade_t *facade,
                               pwm_subsystem_t *pwm,
                               gpio_direction_subsystem_t *direction,
                               current_monitor_subsystem_t *current_mon);

#endif