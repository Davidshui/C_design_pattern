// pwm_subsystem.c
#include "pwm_subsystem.h"
#include <stdio.h>

static void pwm_init(pwm_subsystem_t *pwm)
{
    printf("PWM 子系统初始化完成\n");
}

static void pwm_set_duty(pwm_subsystem_t *pwm, uint16_t duty)
{
    printf("PWM 占空比设置为 %u/1000 (%.1f%%)\n", duty, duty/10.0);
    // 实际：__HAL_TIM_SET_COMPARE(...)
}

static void pwm_start(pwm_subsystem_t *pwm)
{
    printf("PWM 输出启动\n");
}

static void pwm_stop(pwm_subsystem_t *pwm)
{
    printf("PWM 输出停止\n");
}

void pwm_subsystem_init(pwm_subsystem_t *pwm)
{
    if (pwm == NULL) return;
    pwm->init = pwm_init;
    pwm->set_duty = pwm_set_duty;
    pwm->start = pwm_start;
    pwm->stop = pwm_stop;
    pwm->init(pwm);
}