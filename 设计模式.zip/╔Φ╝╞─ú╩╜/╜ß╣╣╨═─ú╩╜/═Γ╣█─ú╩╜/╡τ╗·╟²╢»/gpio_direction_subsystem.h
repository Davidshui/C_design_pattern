// gpio_direction_subsystem.h
#ifndef GPIO_DIRECTION_SUBSYSTEM_H
#define GPIO_DIRECTION_SUBSYSTEM_H

typedef struct gpio_direction_subsystem gpio_direction_subsystem_t;

struct gpio_direction_subsystem {
    void (*init)(gpio_direction_subsystem_t *dir);
    void (*set_forward)(gpio_direction_subsystem_t *dir);
    void (*set_reverse)(gpio_direction_subsystem_t *dir);
};

void gpio_direction_subsystem_init(gpio_direction_subsystem_t *dir);

#endif