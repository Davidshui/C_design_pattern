/*

嵌入式系统中控制一个直流电机或步进电机，通常需要协调多个子系统：

PWM发生器（控制速度）
GPIO方向控制
限位开关/编码器反馈（位置检测）
过流保护（ADC监控电流）
使能控制

直接使用这些子系统会让业务代码非常复杂且容易出错。
外观模式提供简单的高层接口：motor_start()、motor_stop()、motor_set_speed()、motor_emergency_stop() 等。

/*******************************************************************************************************************************************/

/*
业务层 (main.c)
   │
   ▼
外观层 (motor_control_facade_t)   ← 简单接口：start_forward / stop / emergency_stop 等
   │
   └────► 隐藏的子系统：
            ├─ pwm_subsystem_t
            ├─ gpio_direction_subsystem_t
            └─ current_monitor_subsystem_t

*/
// main.c
#include <stdio.h>
#include "motor_control_facade.h"
#include "pwm_subsystem.h"
#include "gpio_direction_subsystem.h"
#include "current_monitor_subsystem.h"

// 所有内存静态分配
static motor_control_facade_t     motor_facade;
static pwm_subsystem_t            motor_pwm;
static gpio_direction_subsystem_t motor_dir;
static current_monitor_subsystem_t current_mon;

int main(void)
{
    // 1. 初始化各子系统
    pwm_subsystem_init(&motor_pwm);
    gpio_direction_subsystem_init(&motor_dir);
    current_monitor_subsystem_init(&current_mon);

    // 2. 初始化电机控制外观
    motor_control_facade_init(&motor_facade, &motor_pwm, &motor_dir, &current_mon);

    // 3. 使用简单的高层接口
    motor_facade.start_forward(&motor_facade, 650);   // 正转，65%速度

    // 模拟运行一段时间
    for (int i = 0; i < 5; i++) {
        motor_facade.update_status(&motor_facade);    // 定期检查保护
        // HAL_Delay(200);
    }

    motor_facade.stop(&motor_facade);

    // 测试反转
    motor_facade.start_reverse(&motor_facade, 400);

    return 0;
}