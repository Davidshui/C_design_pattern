// current_monitor_subsystem.c
#include "current_monitor_subsystem.h"
#include <stdio.h>

static void current_init(current_monitor_subsystem_t *mon)
{
    printf("电流监控子系统初始化完成\n");
}

static uint16_t current_get_ma(current_monitor_subsystem_t *mon)
{
    return 850;   // 模拟850mA
}

static uint8_t current_is_overcurrent(current_monitor_subsystem_t *mon)
{
    return 0;     // 0=正常
}

void current_monitor_subsystem_init(current_monitor_subsystem_t *mon)
{
    if (mon == NULL) return;
    mon->init = current_init;
    mon->get_current_ma = current_get_ma;
    mon->is_overcurrent = current_is_overcurrent;
    mon->init(mon);
}