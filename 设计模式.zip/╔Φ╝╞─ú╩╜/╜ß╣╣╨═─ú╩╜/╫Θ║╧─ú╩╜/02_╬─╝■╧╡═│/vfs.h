/* vfs.h - 嵌入式文件系统风格组合模式 */
#ifndef EMBEDDED_VFS_H
#define EMBEDDED_VFS_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_CHILDREN  12     // 每个目录最多子项数量（可根据 RAM 调整）

/* 统一文件系统组件接口（Component） */
typedef struct fs_node fs_node_t;

typedef struct {
    void (*init)(fs_node_t *self);
    bool (*open)(fs_node_t *self, const char *mode);
    int  (*read)(fs_node_t *self, uint8_t *buf, uint32_t len);
    int  (*write)(fs_node_t *self, const uint8_t *data, uint32_t len);
    void (*list)(fs_node_t *self);                    // 列出目录内容
    bool (*delete)(fs_node_t *self);
    const char *name;
} fs_ops_t;

struct fs_node {
    const fs_ops_t *ops;
    fs_node_t      *parent;
    const char     *name;
    uint32_t        size;          // 文件大小或目录项数量
};

/* 叶子节点：文件 */
typedef struct {
    fs_node_t base;
    uint8_t   *data;               // 模拟文件内容（静态分配）
    uint32_t   capacity;
} fs_file_t;

/* 组合节点：目录 */
typedef struct {
    fs_node_t  base;
    fs_node_t *children[MAX_CHILDREN];
    uint8_t    child_count;
} fs_directory_t;

/* 接口函数（统一操作） */
void fs_init_directory(fs_directory_t *dir, const char *name, fs_node_t *parent);
void fs_init_file(fs_file_t *file, const char *name, uint8_t *data_buf, uint32_t capacity);

void fs_add_child(fs_directory_t *dir, fs_node_t *child);

void fs_open(fs_node_t *node, const char *mode);
int  fs_read(fs_node_t *node, uint8_t *buf, uint32_t len);
int  fs_write(fs_node_t *node, const uint8_t *data, uint32_t len);
void fs_list(fs_node_t *node);
bool fs_delete(fs_node_t *node);

#endif