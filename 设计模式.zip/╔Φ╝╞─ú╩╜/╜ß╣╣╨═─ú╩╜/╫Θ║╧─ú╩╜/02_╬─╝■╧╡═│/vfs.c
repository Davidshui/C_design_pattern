/* vfs.c */
#include "vfs.h"
#include <stdio.h>

void fs_open(fs_node_t *node, const char *mode)
{
    if (node && node->ops && node->ops->open)
        node->ops->open(node, mode);
}

int fs_read(fs_node_t *node, uint8_t *buf, uint32_t len)
{
    if (node && node->ops && node->ops->read)
        return node->ops->read(node, buf, len);
    return -1;
}

int fs_write(fs_node_t *node, const uint8_t *data, uint32_t len)
{
    if (node && node->ops && node->ops->write)
        return node->ops->write(node, data, len);
    return -1;
}

void fs_list(fs_node_t *node)
{
    if (node && node->ops && node->ops->list)
        node->ops->list(node);
}

bool fs_delete(fs_node_t *node)
{
    if (node && node->ops && node->ops->delete)
        return node->ops->delete(node);
    return false;
}