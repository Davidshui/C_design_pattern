/* vfs_impl.c */
#include "vfs.h"
#include <stdio.h>
#include <string.h>

/* ====================== 文件（叶子节点）操作 ====================== */
static void file_open(fs_node_t *self, const char *mode)
{
    (void)mode;
    printf("[File] 打开文件: %s\n", self->name);
}

static int file_read(fs_node_t *self, uint8_t *buf, uint32_t len)
{
    fs_file_t *file = (fs_file_t *)self;
    uint32_t copy_len = (len < file->size) ? len : file->size;
    memcpy(buf, file->data, copy_len);
    printf("[File] 读取 %s, 长度 %u\n", self->name, copy_len);
    return copy_len;
}

static int file_write(fs_node_t *self, const uint8_t *data, uint32_t len)
{
    fs_file_t *file = (fs_file_t *)self;
    if (len > file->capacity) len = file->capacity;
    memcpy(file->data, data, len);
    file->size = len;
    printf("[File] 写入 %s, 长度 %u\n", self->name, len);
    return len;
}

static void file_list(fs_node_t *self)
{
    printf("  📄 %s (%u bytes)\n", self->name, self->size);
}

static const fs_ops_t file_ops = {
    .open   = file_open,
    .read   = file_read,
    .write  = file_write,
    .list   = file_list,
    .delete = NULL,
    .name   = "File"
};

/* ====================== 目录（组合节点）操作 ====================== */
static void dir_open(fs_node_t *self, const char *mode)
{
    (void)mode;
    printf("[Dir] 进入目录: %s\n", self->name);
}

static void dir_list(fs_node_t *self)
{
    fs_directory_t *dir = (fs_directory_t *)self;
    printf("📁 %s/  (%d 项)\n", self->name, dir->child_count);
    for (uint8_t i = 0; i < dir->child_count; i++) {
        fs_list(dir->children[i]);
    }
}

static const fs_ops_t dir_ops = {
    .open   = dir_open,
    .read   = NULL,
    .write  = NULL,
    .list   = dir_list,
    .delete = NULL,
    .name   = "Directory"
};

/* ====================== 初始化函数 ====================== */
void fs_init_directory(fs_directory_t *dir, const char *name, fs_node_t *parent)
{
    dir->base.ops = &dir_ops;
    dir->base.parent = parent;
    dir->base.name = name;
    dir->base.size = 0;
    dir->child_count = 0;
}

void fs_init_file(fs_file_t *file, const char *name, uint8_t *data_buf, uint32_t capacity)
{
    file->base.ops = &file_ops;
    file->base.parent = NULL;
    file->base.name = name;
    file->base.size = 0;
    file->data = data_buf;
    file->capacity = capacity;
}

void fs_add_child(fs_directory_t *dir, fs_node_t *child)
{
    if (dir->child_count < MAX_CHILDREN) {
        dir->children[dir->child_count++] = child;
        child->parent = (fs_node_t *)dir;
        dir->base.size++;   // 目录大小记录子项数量
    }
}