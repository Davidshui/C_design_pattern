/* main.c */
/*
统一接口：上层代码（应用层）无需区分文件和目录，极大简化逻辑。
树形结构：天然支持多级目录，符合直觉。
*/
#include "vfs.h"
#include <stdio.h>

static uint8_t config_data[256];
static uint8_t log_data[512];

int main(void)
{
    fs_directory_t root, config_dir, data_dir;
    fs_file_t config_file, log_file, readme;

    /* 构建文件系统树 */
    fs_init_directory(&root, "/", NULL);
    fs_init_directory(&config_dir, "config", (fs_node_t*)&root);
    fs_init_directory(&data_dir, "data", (fs_node_t*)&root);

    fs_init_file(&config_file, "system.cfg", config_data, sizeof(config_data));
    fs_init_file(&log_file, "system.log", log_data, sizeof(log_data));
    fs_init_file(&readme, "README.txt", NULL, 0);

    fs_add_child(&root, (fs_node_t*)&config_dir);
    fs_add_child(&root, (fs_node_t*)&data_dir);
    fs_add_child(&root, (fs_node_t*)&readme);

    fs_add_child(&config_dir, (fs_node_t*)&config_file);
    fs_add_child(&data_dir, (fs_node_t*)&log_file);

    printf("=== 嵌入式组合模式 - 文件系统风格演示 ===\n\n");

    /* 统一操作：不管是目录还是文件，都用同一套接口 */
    fs_list((fs_node_t*)&root);           // 显示根目录

    printf("\n--- 进入 config 目录 ---\n");
    fs_open((fs_node_t*)&config_dir, "r");
    fs_list((fs_node_t*)&config_dir);

    printf("\n--- 读取配置文件 ---\n");
    uint8_t buf[64];
    fs_read((fs_node_t*)&config_file, buf, 64);

    printf("\n--- 写入日志 ---\n");
    const char *log_str = "Boot completed at 2026-04-03";
    fs_write((fs_node_t*)&log_file, (const uint8_t*)log_str, strlen(log_str));

    return 0;
}