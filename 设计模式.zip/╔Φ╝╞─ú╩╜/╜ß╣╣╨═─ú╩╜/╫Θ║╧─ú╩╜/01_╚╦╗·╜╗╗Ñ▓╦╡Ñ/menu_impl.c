/* menu_impl.c */
#include "menu.h"
#include <stdio.h>

/* ====================== 叶子节点操作 ====================== */
static void leaf_enter(menu_component_t *self)
{
    printf("[Leaf] 进入功能页: %s\n", self->title);
}

static void leaf_select(menu_component_t *self)
{
    menu_leaf_t *leaf = (menu_leaf_t *)self;
    printf("[Leaf] 执行功能: %s\n", self->title);
    if (leaf->execute)
        leaf->execute();
}

static void leaf_display(menu_component_t *self)
{
    printf("  → %s\n", self->title);
}

static const menu_ops_t leaf_ops = {
    .enter   = leaf_enter,
    .exit    = NULL,
    .select  = leaf_select,
    .back    = NULL,
    .display = leaf_display,
    .name    = "MenuLeaf"
};

/* ====================== 组合节点操作 ====================== */
static void composite_enter(menu_component_t *self)
{
    menu_composite_t *comp = (menu_composite_t *)self;
    printf("\n[Menu] 进入菜单: %s (%d 项)\n", self->title, comp->child_count);
    menu_display(self);
}

static void composite_select(menu_component_t *self)
{
    menu_composite_t *comp = (menu_composite_t *)self;
    if (comp->current_index < comp->child_count) {
        menu_component_t *child = comp->children[comp->current_index];
        menu_enter(child);
    }
}

static void composite_back(menu_component_t *self)
{
    if (self->parent) {
        printf("[Menu] 返回上级菜单: %s\n", self->parent->title);
        menu_enter(self->parent);
    } else {
        printf("[Menu] 已是最顶层菜单\n");
    }
}

static void composite_display(menu_component_t *self)
{
    menu_composite_t *comp = (menu_composite_t *)self;
    printf("菜单: %s\n", self->title);
    for (uint8_t i = 0; i < comp->child_count; i++) {
        printf("%c %s\n", (i == comp->current_index) ? '>' : ' ', 
               comp->children[i]->title);
    }
}

static const menu_ops_t composite_ops = {
    .enter   = composite_enter,
    .exit    = NULL,
    .select  = composite_select,
    .back    = composite_back,
    .display = composite_display,
    .name    = "MenuComposite"
};

/* ====================== 初始化函数 ====================== */
void menu_init_composite(menu_composite_t *menu, const char *title, menu_component_t *parent)
{
    menu->base.ops = &composite_ops;
    menu->base.parent = parent;
    menu->base.title = title;
    menu->child_count = 0;
    menu->current_index = 0;
}

void menu_init_leaf(menu_leaf_t *leaf, const char *title, void (*execute)(void))
{
    leaf->base.ops = &leaf_ops;
    leaf->base.parent = NULL;
    leaf->base.title = title;
    leaf->execute = execute;
}

void menu_add_child(menu_composite_t *parent, menu_component_t *child)
{
    if (parent->child_count < MAX_CHILDREN) {
        parent->children[parent->child_count++] = child;
        child->parent = (menu_component_t *)parent;
    }
}