/* menu.h */
#ifndef EMBEDDED_COMPOSITE_MENU_H
#define EMBEDDED_COMPOSITE_MENU_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_CHILDREN  8     // 每个菜单最多子项数量

/* 菜单组件统一接口（Component） */
typedef struct menu_component menu_component_t;

typedef struct {
    void (*enter)(menu_component_t *self);      // 进入菜单
    void (*exit)(menu_component_t *self);       // 退出菜单
    void (*select)(menu_component_t *self);     // 选择当前项
    void (*back)(menu_component_t *self);       // 返回上一级
    void (*display)(menu_component_t *self);    // 显示当前菜单内容
    const char *name;
} menu_ops_t;

struct menu_component {
    const menu_ops_t *ops;
    menu_component_t *parent;                   // 父菜单
    const char       *title;
};

/* 叶子节点（具体功能项） */
typedef struct {
    menu_component_t base;
    void (*execute)(void);                      // 执行具体功能
} menu_leaf_t;

/* 组合节点（菜单容器） */
typedef struct {
    menu_component_t base;
    menu_component_t *children[MAX_CHILDREN];
    uint8_t child_count;
    uint8_t current_index;                      // 当前选中项索引
} menu_composite_t;

/* 接口函数 */
void menu_init_composite(menu_composite_t *menu, const char *title, menu_component_t *parent);
void menu_init_leaf(menu_leaf_t *leaf, const char *title, void (*execute)(void));

void menu_add_child(menu_composite_t *parent, menu_component_t *child);

void menu_enter(menu_component_t *component);
void menu_exit(menu_component_t *component);
void menu_select(menu_component_t *component);
void menu_back(menu_component_t *component);
void menu_display(menu_component_t *component);

#endif