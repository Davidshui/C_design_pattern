/* main.c */
/*
需求：
主菜单
├── 系统设置
│   ├── 显示设置
│   ├── 网络设置
│   └── 时间设置
├── 设备监控
│   ├── 温度监控
│   ├── 电压监控
│   └── 状态汇总
└── 关于本机

用户希望统一操作：enter()、exit()、select()、back()，
不管是叶子节点（具体功能）还是组合节点（菜单组）

*/

/*
组合模式使用：
统一操作：上层代码用同一套接口操作菜单，无论它是叶子还是容器。
动态扩展：可以运行时添加/删除子菜单。
*/
#include "menu.h"
#include <stdio.h>

static void func_about(void)
{
    printf("关于本机: 嵌入式组合模式演示 v1.0\n");
}

static void func_temp(void)
{
    printf("温度监控: 当前温度 25.6°C\n");
}

int main(void)
{
    menu_composite_t root, settings, monitor;
    menu_leaf_t about, temp_monitor;

    /* 构建菜单树 */
    menu_init_composite(&root, "主菜单", NULL);
    menu_init_composite(&settings, "系统设置", (menu_component_t*)&root);
    menu_init_composite(&monitor, "设备监控", (menu_component_t*)&root);

    menu_init_leaf(&about, "关于本机", func_about);
    menu_init_leaf(&temp_monitor, "温度监控", func_temp);

    /* 组装菜单结构 */
    menu_add_child(&root, (menu_component_t*)&settings);
    menu_add_child(&root, (menu_component_t*)&monitor);
    menu_add_child(&root, (menu_component_t*)&about);

    menu_add_child(&monitor, (menu_component_t*)&temp_monitor);

    printf("=== 嵌入式组合模式 - 多级菜单系统演示 ===\n\n");

    menu_enter((menu_component_t*)&root);     // 进入主菜单
    menu_select((menu_component_t*)&root);    // 进入第一个子菜单（系统设置）
    menu_back((menu_component_t*)&settings);  // 返回上级

    return 0;
}