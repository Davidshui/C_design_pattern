/* menu.c */
#include "menu.h"
#include <stdio.h>

void menu_enter(menu_component_t *c)
{
    if (c && c->ops && c->ops->enter)
        c->ops->enter(c);
}

void menu_exit(menu_component_t *c)
{
    if (c && c->ops && c->ops->exit)
        c->ops->exit(c);
}

void menu_select(menu_component_t *c)
{
    if (c && c->ops && c->ops->select)
        c->ops->select(c);
}

void menu_back(menu_component_t *c)
{
    if (c && c->ops && c->ops->back)
        c->ops->back(c);
}

void menu_display(menu_component_t *c)
{
    if (c && c->ops && c->ops->display)
        c->ops->display(c);
}