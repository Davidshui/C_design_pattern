#include "db.h"
#include <stdio.h>
#include <string.h>

typedef struct {
    const char* connection_string;
    int is_connected;
} real_db_data_t;

static void real_query(db_t* self, const char* sql, char* result, int result_size)
{
    real_db_data_t* data = (real_db_data_t*)self->private_data;
    
    if (!data->is_connected) {
        printf("【Real DB】正在建立数据库连接: %s\n", data->connection_string);
        data->is_connected = 1;
    }

    snprintf(result, result_size, "[查询结果] %s", sql);
    printf("【Real DB】执行查询完成\n");
}

static void real_execute(db_t* self, const char* sql)
{
    real_db_data_t* data = (real_db_data_t*)self->private_data;
    
    if (!data->is_connected) {
        printf("【Real DB】正在建立数据库连接: %s\n", data->connection_string);
        data->is_connected = 1;
    }

    printf("【Real DB】执行写操作: %s\n", sql);
}

static void real_close(db_t* self)
{
    real_db_data_t* data = (real_db_data_t*)self->private_data;
    if (data->is_connected) {
        printf("【Real DB】关闭数据库连接\n");
        data->is_connected = 0;
    }
}

static void real_destroy(db_t* self)
{
    printf("【Real DB】资源已释放\n");
}

// 初始化真实数据库对象
void init_real_db(db_t* db, 
                  real_db_data_t* data, 
                  const char* connection_string)
{
    data->connection_string = connection_string;
    data->is_connected = 0;

    db->private_data = data;
    db->query    = real_query;
    db->execute  = real_execute;
    db->close    = real_close;
    db->destroy  = real_destroy;
}