#include "db.h"
#include <stdio.h>

typedef struct {
    db_t real_db;               // 内部真实数据库对象
    real_db_data_t real_data;   // 真实数据库配置数据
    int real_db_inited;         // 是否已初始化真实对象
    const char* connection_string;
    user_level_t user_level;
} proxy_data_t;

static void proxy_query(db_t* self, const char* sql, char* result, int result_size)
{
    proxy_data_t* data = (proxy_data_t*)self->private_data;

    // 虚拟代理：第一次操作时才初始化真实连接
    if (!data->real_db_inited) {
        printf("【Proxy】首次操作，正在初始化真实数据库连接...\n");
        init_real_db(&data->real_db, &data->real_data, data->connection_string);
        data->real_db_inited = 1;
    }

    data->real_db.query(&data->real_db, sql, result, result_size);
}

static void proxy_execute(db_t* self, const char* sql)
{
    proxy_data_t* data = (proxy_data_t*)self->private_data;

    // 保护代理：只有管理员才能执行写操作
    if (data->user_level < USER_ADMIN) {
        printf("【Proxy】权限不足！只有管理员才能执行写操作。\n");
        return;
    }

    if (!data->real_db_inited) {
        printf("【Proxy】首次操作，正在初始化真实数据库连接...\n");
        init_real_db(&data->real_db, &data->real_data, data->connection_string);
        data->real_db_inited = 1;
    }

    data->real_db.execute(&data->real_db, sql);
}

static void proxy_close(db_t* self)
{
    proxy_data_t* data = (proxy_data_t*)self->private_data;
    if (data->real_db_inited) {
        data->real_db.close(&data->real_db);
    }
}

static void proxy_destroy(db_t* self)
{
    printf("【Proxy】代理资源已释放\n");
}

// 初始化代理
void init_db_proxy(db_t* proxy, 
                   proxy_data_t* data, 
                   const char* connection_string, 
                   user_level_t user_level)
{
    data->real_db_inited = 0;
    data->connection_string = connection_string;
    data->user_level = user_level;

    proxy->private_data = data;
    proxy->query   = proxy_query;
    proxy->execute = proxy_execute;
    proxy->close   = proxy_close;
    proxy->destroy = proxy_destroy;
}