/**
数据库连接代理（虚拟代理 + 保护代理）：

真实数据库连接非常耗资源（模拟网络连接），代理负责：
延迟连接：第一次执行查询时才真正建立连接
权限控制：只有管理员才能执行写操作
*/
#include "db.h"
#include <stdio.h>

// 调用者提供所有内存
static db_t db_proxy;
static proxy_data_t proxy_data;

int main(void)
{
    char result[128];

    printf("=== C语言代理模式演示（数据库连接代理） ===\n\n");

    // 初始化为普通用户
    init_db_proxy(&db_proxy, &proxy_data, "server=localhost;user=guest", USER_NORMAL);

    printf("普通用户执行查询：\n");
    db_proxy.query(&db_proxy, "SELECT * FROM users", result, sizeof(result));
    printf("查询结果: %s\n", result);

    printf("\n普通用户尝试写操作：\n");
    db_proxy.execute(&db_proxy, "UPDATE users SET name='test'");

    printf("\n");

    // 切换为管理员权限
    init_db_proxy(&db_proxy, &proxy_data, "server=localhost;user=admin", USER_ADMIN);

    printf("管理员执行查询：\n");
    db_proxy.query(&db_proxy, "SELECT * FROM users", result, sizeof(result));
    printf("查询结果: %s\n", result);

    printf("\n管理员执行写操作：\n");
    db_proxy.execute(&db_proxy, "UPDATE users SET name='admin_test'");

    // 清理
    db_proxy.close(&db_proxy);
    db_proxy.destroy(&db_proxy);

    return 0;
}