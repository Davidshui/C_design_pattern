#ifndef DB_H
#define DB_H

// 数据库接口（Subject）
typedef struct db {
    void (*query)(struct db* self, const char* sql, char* result, int result_size);
    void (*execute)(struct db* self, const char* sql);   // 写操作
    void (*close)(struct db* self);
    void (*destroy)(struct db* self);

    void* private_data;
} db_t;

// 用户权限级别
typedef enum {
    USER_NORMAL = 0,
    USER_ADMIN  = 1
} user_level_t;

#endif